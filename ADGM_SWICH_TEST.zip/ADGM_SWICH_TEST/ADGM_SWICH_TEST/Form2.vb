﻿' 載入設定檔
Imports System.Configuration
'Imports System.Windows.Forms.DataVisualization.Charting
Imports System.IO.Ports ' 需要引用 System.IO.Ports 命名空間


Public Class Form2
    ' 初始化連線狀態
    Dim isConnected As Boolean = False
    ' Private dataBuffer As New List(Of Byte) ' 用於存儲串口接收緩存中的數據

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        ' 載入表單時搜尋可用的COM Port，並將其列入ComboBox1選單中
        Dim ports() As String = IO.Ports.SerialPort.GetPortNames()
        For Each port As String In ports
            ComboBox1.Items.Add(port)
        Next

        Timer1.Interval = 600000 '設定Timer計時10分鐘 斷開Com Port
        Timer1.Enabled = True

        UpdateDateTime() '顯示當前時間
        Label1.Text = "未連線"
        Button1.Text = "連線"
        RadioButton1.Text = "持續執行"
        RadioButton2.Text = "單次執行"
        Button2.Text = "指令發送"
        Button3.Text = "開始測試"
        Label3.Text = "重複次數設定:"
        Label4.Text = "時間間隔設定:"

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' 關閉 SerialPort1
        SerialPort1.Close()
    End Sub

    ' ComboBox1 選擇 COM Port 後的事件處理函式
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        ' 在選擇 COM Port 後，進行連線
        ' If ComboBox1.SelectedItem IsNot Nothing Then
        ' 嘗試連線
        'Connect()
        'End If
    End Sub

    ' 按下 Button1 的事件處理函式
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        If isConnected Then
            ' 斷開連線
            Disconnect()
        Else
            ' 未連線時，提示用戶選擇 COM Port
            ' MsgBox("請選擇要連線的 COM Port！")
            If ComboBox1.SelectedItem IsNot Nothing Then
                On Error GoTo err1
                ' 建立 SerialPort 物件
                SerialPort1.PortName = ComboBox1.SelectedItem.ToString() ' 指定 Arduino 連接埠編號
                SerialPort1.BaudRate = 9600 ' 設定鮑率
                'SerialPort1.ReadBufferSize = 65536 ' 設定讀取緩衝區大小
                'SerialPort1.WriteBufferSize = 65536 ' 設定寫入緩衝區大小
                SerialPort1.Parity = System.IO.Ports.Parity.None ' 設定校驗位
                SerialPort1.DataBits = 8 ' 設定資料位元數
                SerialPort1.StopBits = System.IO.Ports.StopBits.One ' 設定停止位元數
                'SerialPort1.ReadTimeout = 500
                'SerialPort1.WriteTimeout = 500
                ' 開啟連線
                SerialPort1.Open()
                ' 連線成功，更新界面狀態
                Connect()
            Else
                MsgBox("請選擇要連線的 COM Port！")
            End If
        End If

        Exit Sub
err1:
        MsgBox(ComboBox1.SelectedItem.ToString() & " : 已與設備斷線，請確認!")

    End Sub

    ' 建立連線的程式碼
    Private Sub Connect()
        ' 實現連線的程式碼
        ' 當連線成功時，將 isConnected 設為 True，並更新 Label1 的文字
        isConnected = True
        Label1.Text = "已連線到" & ComboBox1.SelectedItem.ToString()
        'Dim label1Text As String = ConfigurationManager.AppSettings("Label1Text") & "已連線到" & ComboBox1.SelectedItem.ToString()
        Label1.ForeColor = Color.FromArgb(0, 255, 0) ' 設定文字顏色為綠色
        Button1.Text = "斷線"
        ComboBox1.Enabled = False
    End Sub

    ' 斷開連線的程式碼
    Private Sub Disconnect()
        ' 實現斷開連線的程式碼
        ' 當斷開連線成功時，將 isConnected 設為 False，並更新 Label1 的文字
        isConnected = False
        Label1.Text = "已斷開連線"
        'Dim label1Text As String = ConfigurationManager.AppSettings("Label1Text") & "已斷開"
        Label1.ForeColor = Color.FromArgb(255, 0, 0) ' 設定文字顏色為紅色
        Button1.Text = "連線"
        ComboBox1.Enabled = True

        ' 關閉連線
        SerialPort1.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click

        If SerialPort1.IsOpen Then

            '傳送指令給Arduino
            sendCommand(TextBox1.Text)

            ' 啟動 Timer2
            Timer2.Enabled = True
        Else
            MsgBox("已斷開連線！")
        End If

    End Sub

    Private Sub UpdateDateTime()
        ' 取得目前日期與時間
        Dim now As DateTime = DateTime.Now

        ' 顯示日期時間於 Label1 上
        Label2.Text = now.ToString("yyyy/MM/dd HH:mm:ss")
    End Sub

    Private WithEvents Timer1 As New Timer()

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        '關閉SerialPort連線
        If SerialPort1.IsOpen Then
            Disconnect()
            MessageBox.Show("SerialPort已關閉")
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove
        '重新啟動Timer計時
        Timer1.Enabled = False
        Timer1.Enabled = True
    End Sub

    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived

        Try
            ' 讀取從Arduino發送的訊息
            Dim message As String = SerialPort1.ReadLine()
            ' 將讀取的訊息傳到UI執行緒上更新TextBox的值
            SetText(message)
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try

    End Sub

    Private Sub sendCommand(ByVal command As String)
        ' 傳送指令給Arduino
        SerialPort1.Write(command)
    End Sub

    '使用delegate傳遞資料到UI執行緒
    Delegate Sub SetTextCallback(ByVal [text] As String)

    '使用Invoke確保程式在UI執行緒上執行
    Private Sub SetText(ByVal [text] As String)
        ' 檢查是否需要使用Invoke
        If Me.TextBox2.InvokeRequired Then
            Dim d As New SetTextCallback(AddressOf SetText)
            Me.Invoke(d, New Object() {[text]})
        Else
            Me.TextBox2.Text = [text]
        End If
    End Sub
End Class