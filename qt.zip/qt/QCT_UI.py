# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'QCT.ui'
#
#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import pyodbc
from PyQt5.QtWidgets import QApplication, QMainWindow, QComboBox, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QCheckBox
from PyQt5.QtChart import QChart, QChartView, QLineSeries
from PyQt5.QtGui import QPainter,QFont
from PyQt5.QtCore import Qt,QRect
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def __init__(self):


         # 連接Access資料庫
        self.conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\ZK維修轉換\QCT_DataBase.accdb;Uid=Admin;Pwd=;')
        self.cursor = self.conn.cursor()

    def closeEvent(self, event):
        # 視窗關閉時關閉資料庫連接
        self.conn.close()
        event.accept()

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1090, 850)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(40, 40, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(200, 40, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(340, 40, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(560, 30, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(40, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(200, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(340, 100, 131, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_7.setFont(font)
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(560, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_8.setFont(font)
        self.label_8.setObjectName("label_8")
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(700, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_9.setFont(font)
        self.label_9.setObjectName("label_9")
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(840, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_10.setFont(font)
        self.label_10.setObjectName("label_10")
        self.comboBox_1 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_1.setGeometry(QtCore.QRect(40, 70, 151, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_1.setFont(font)
        self.comboBox_1.setObjectName("comboBox")
        self.comboBox_2 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_2.setGeometry(QtCore.QRect(200, 70, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_2.setFont(font)
        self.comboBox_2.setObjectName("comboBox_2")
        self.comboBox_3 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_3.setGeometry(QtCore.QRect(340, 70, 211, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_3.setFont(font)
        self.comboBox_3.setObjectName("comboBox_3")
        self.comboBox_4 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_4.setGeometry(QtCore.QRect(560, 70, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_4.setFont(font)
        self.comboBox_4.setObjectName("comboBox_4")
        self.comboBox_5 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_5.setGeometry(QtCore.QRect(40, 130, 151, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_5.setFont(font)
        self.comboBox_5.setObjectName("comboBox_5")
        self.comboBox_6 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_6.setGeometry(QtCore.QRect(200, 130, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_6.setFont(font)
        self.comboBox_6.setObjectName("comboBox_6")
        self.comboBox_7 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_7.setGeometry(QtCore.QRect(340, 130, 211, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_7.setFont(font)
        self.comboBox_7.setObjectName("comboBox_7")
        self.comboBox_8 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_8.setGeometry(QtCore.QRect(560, 130, 131, 21))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_8.setFont(font)
        self.comboBox_8.setObjectName("comboBox_8")
        self.comboBox_9 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_9.setGeometry(QtCore.QRect(700, 130, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_9.setFont(font)
        self.comboBox_9.setObjectName("comboBox_9")
        self.comboBox_10 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_10.setGeometry(QtCore.QRect(840, 130, 221, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_10.setFont(font)
        self.comboBox_10.setObjectName("comboBox_10")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(40, 430, 1021, 371))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.widget.setFont(font)
        self.widget.setObjectName("widget")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1091, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowIcon(QtGui.QIcon('kite.png'))
        MainWindow.setWindowTitle(_translate("MainWindow", "HEALTH RATE WEEKLY TREND - LOADBOARD"))
        self.label.setText(_translate("MainWindow", "Report Year"))
        self.label_2.setText(_translate("MainWindow", "Report Month"))
        self.label_3.setText(_translate("MainWindow", "Device Name"))
        self.label_4.setText(_translate("MainWindow", "SAT"))
        self.label_5.setText(_translate("MainWindow", "STATUS"))
        self.label_6.setText(_translate("MainWindow", "DUT"))
        self.label_7.setText(_translate("MainWindow", "Production Line"))
        self.label_8.setText(_translate("MainWindow", "VENDOR"))
        self.label_9.setText(_translate("MainWindow", "Location"))
        self.label_10.setText(_translate("MainWindow", "Package Type"))

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT Format([CH_DATE],'yyyy') as Y_Date FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_1.addItem('(ALL)')
        for row in results:
            self.comboBox_1.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT Format([CH_DATE],'m') as M_Date FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_2.addItem('(ALL)')
        for row in results:
            self.comboBox_2.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Device_Name] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_3.addItem('(ALL)')
        for row in results:
            self.comboBox_3.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [SAT] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_4.addItem('(ALL)')
        for row in results:
            self.comboBox_4.addItem(row[0])

         # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [STATUS] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_5.addItem('(ALL)')
        for row in results:
            self.comboBox_5.addItem(row[0])

         # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [DUT] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_6.addItem('(ALL)')
        for row in results:
            self.comboBox_6.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Tester_Platform] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_7.addItem('(ALL)')
        for row in results:
            self.comboBox_7.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [VENDOR] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_8.addItem('(ALL)')
        for row in results:
            self.comboBox_8.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Location] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_9.addItem('(ALL)')
        for row in results:
            self.comboBox_9.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [PACKAGE_TYPE] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_10.addItem('(ALL)')
        for row in results:
            self.comboBox_10.addItem(row[0])


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
