﻿' 載入設定檔
Imports System.Configuration
'Imports System.Windows.Forms.DataVisualization.Charting
Imports System.IO.Ports

Public Class Form2
    Dim isConnected As Boolean = False
    Dim Arduino_coed As String = "10"
    Dim led_close As String = "21"
    Dim result As Boolean = False

   

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        Timer1.Interval = 600000
        Timer1.Enabled = True

        UpdateDateTime()
        Label1.Text = "未連線"
        Button1.Text = "連線"
        RadioButton1.Text = "持續執行"
        RadioButton2.Text = "單次執行"
        Button2.Text = "測試"
        Label3.Text = "測試次數設定:"
        Label4.Text = "時間間隔設定:"
        Button3.Text = "清除"
        TextBox2.Multiline = True
        TextBox2.ScrollBars = ScrollBars.Vertical
        Label5.Text = ""

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        SerialPort1.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click 'port Conntect
        If isConnected Then
            Disconnect()
        Else
            If ComboBox1.SelectedItem IsNot Nothing Then
                On Error GoTo err1
                SerialPort1.PortName = ComboBox1.SelectedItem.ToString()
                SerialPort1.BaudRate = 9600
                SerialPort1.Parity = System.IO.Ports.Parity.None
                SerialPort1.DataBits = 8
                SerialPort1.StopBits = System.IO.Ports.StopBits.One
                SerialPort1.Handshake = Handshake.None
                SerialPort1.RtsEnable = True
                SerialPort1.Open()
                Connect()
            Else
                MsgBox("請選擇要連線的 COM Port！")
            End If
        End If

        Exit Sub
err1:
        MsgBox(ComboBox1.SelectedItem.ToString() & " : 已與設備斷線，請確認!")

    End Sub

    Private Sub Connect()
        isConnected = True
        Label1.Text = "已連線到" & ComboBox1.SelectedItem.ToString()
        Label1.ForeColor = Color.FromArgb(110, 170, 45)
        Button1.Text = "斷線"
        ComboBox1.Enabled = False
    End Sub

    Private Sub Disconnect()
        isConnected = False
        Label1.Text = "已斷開連線"
        Label1.ForeColor = Color.FromArgb(255, 0, 0)
        Button1.Text = "連線"
        ComboBox1.Enabled = True
        SerialPort1.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click ' 測試

        Dim test_items, i As Integer

        test_items = NumericUpDown1.Value
        Label5.Text = ""

        If SerialPort1.IsOpen Then
            For i = 1 To test_items
                ' Timer2.Enabled = True
                ' sendCommand(TextBox1.Text)
                sendCommand(Arduino_coed)
                TextBox2.Clear()
            Next
            sendCommand(led_close)

            If result = True Then
                Result_pass()
                result = False
            End If
        Else
            MsgBox("已斷開連線！")
        End If

    End Sub

    Private Sub UpdateDateTime()
        Dim now As DateTime = DateTime.Now
        Label2.Text = now.ToString("yyyy/MM/dd HH:mm:ss")
    End Sub

    Private WithEvents Timer1 As New Timer()

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        If SerialPort1.IsOpen Then
            Disconnect()
            MessageBox.Show("SerialPort已關閉")
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove
        Timer1.Enabled = False
        Timer1.Enabled = True
    End Sub

    Private Sub sendCommand(ByVal command As String)
        SerialPort1.Write(command)
    End Sub

    Delegate Sub SetTextCallback(ByVal [text] As String)
  
    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        ReceivedText(SerialPort1.ReadExisting())
    End Sub

    Private Sub ReceivedText(ByVal [text] As String)

        If Me.TextBox2.InvokeRequired Then
            Dim x As New SetTextCallback(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.TextBox2.Text &= [text]
        End If

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Label5.Text = ""
        TextBox2.Clear()
    End Sub

    Private Sub ComboBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ComboBox1.MouseClick
        Dim ports() As String = IO.Ports.SerialPort.GetPortNames()

        ComboBox1.Items.Clear()

        For Each port As String In ports
            ComboBox1.Items.Add(port)
        Next
    End Sub

    Private Sub Result_pass()
        Dim m As Integer = 0
        Dim y As Integer = 0

        Dim parts() As String = Split(TextBox2.Text, ",")

        For Each i As String In parts

            If parts(m) = "PASS" Then
                y = y + 1

            End If

            'MessageBox.Show(parts(m) & "__" & m)
            m = m + 1
        Next

        MessageBox.Show(y)

        If y = 4 * NumericUpDown1.Value Then
            Label5.Text = "PASS"
            Label5.ForeColor = Color.FromArgb(110, 170, 45)
        Else
            Label5.Text = "FAIL"
            Label5.ForeColor = Color.FromArgb(255, 0, 0)
        End If

        'MessageBox.Show(parts(2) & "__" & m & "__" & parts(3))

    End Sub


End Class
