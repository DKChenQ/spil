﻿Public Class NewUser

    Private access As New DBControl

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.Close()
    End Sub

    Private Sub TextBox_Vaildate(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserName_TextBox.TextChanged, Password_TextBox.TextChanged

        If Not String.IsNullOrWhiteSpace(UserName_TextBox.Text) AndAlso Not String.IsNullOrWhiteSpace(Password_TextBox.Text) Then Save_Button.Enabled = True

    End Sub

    Private Sub AddUser()
        'ADD PARAMETERS
        access.AddParams("@user", UserName_TextBox.Text)
        access.AddParams("@pass", Password_TextBox.Text)
        access.AddParams("@ph", Phone_TextBox.Text)

        'EXECUTE INSERT COMMAND
        access.ExecQuery("INSERT INTO Mers (UserName,[Password], Phone) " & _
                         "VALUES (@user,@pass,@ph); ")

        'report & abort on errors
        If Not String.IsNullOrEmpty(access.EXception) Then MsgBox(access.EXception) : Exit Sub

        'SUCCESS!!
        MsgBox("User was added successfully.")

        Form1.RefreshGrid()

        Me.Close()

    End Sub

    Private Sub NewUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Save_Button.Enabled = False

    End Sub

    Private Sub Save_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Save_Button.Click

        AddUser()

    End Sub
End Class