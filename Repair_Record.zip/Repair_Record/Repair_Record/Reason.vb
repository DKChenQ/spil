﻿Public Class Reason


    Private Sub Reason_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        Cob_FailReason.Items.Add("")
        Cob_FailReason.Items.Add("Low Yield")
        Cob_FailReason.Items.Add("No Pass")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click




        Me.Close()


    End Sub
End Class