﻿Imports Microsoft.Office.Interop.Access


Public Class Class1_Access

    Public Shared Sub CompactDbFile() '壓縮ACCESS資料庫

        Dim sFilePath As String = "E:\VB_TEST\2021計畫\Record\PMS_Database_Auto_LB_CP.accdb" '"來源檔案完整路徑(source)"
        Dim dFilePath As String = "E:\VB_TEST\2021計畫\Record\PMS_Database_Auto_LB_CP_U.accdb" '"目的檔案完整路徑(destination)"

        Dim AceDao As New Dao.DBEngine
        AceDao.CompactDatabase(sFilePath, dFilePath, _
                               Dao.LanguageConstants.dbLangChineseTraditional, _
                               Dao.DatabaseTypeEnum.dbVersion140)

    End Sub

End Class
