﻿Imports System.Data.OleDb
Imports EXCEL = Microsoft.Office.Interop.Excel

Public Class DutBoard_Fail_Code
    Dim NUMB As Long

    Private Sub DutBoard_Fail_Code_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        OpenForm = False
    End Sub

    Private Sub DutBoard_Fail_Code_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        MaximizeBox = False
        MinimizeBox = False
        DGView1.ReadOnly = True
        DGView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DB_Load()
        Button1.Enabled = False
    End Sub

    Private Sub DB_Load()

        Dim DBCon As OleDbConnection

        DBCon = New OleDbConnection(Dut_Board)

        Dim Str As String = "Select * From AoD_Fail_Code ORDER BY In_DATE DESC, Aod_No" '派工 資料查詢表

        Dim cmd As OleDbCommand = New OleDbCommand(Str, DBCon)
        DBCon.Open()

        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        'DBDA = New OleDbDataAdapter(cmd)

        DBST = New DataSet()
        'DBDT = New DataTable

        LB_Temp.Fill(DBST, "AoD_Temp")
        'DBST.Tables("AoD_Temp").Columns.Remove("ID")
        DBST.Tables("Aod_Temp").Columns("In_Date").SetOrdinal(1)

        DGView1.DataSource = DBST.Tables("AoD_Temp").DefaultView
        DGView1.Columns("In_Date").HeaderText = "Date"

        DGView1.Columns("In_Date").DefaultCellStyle.Format = "yyyy/MM/dd"
        DBCon.Close()

    End Sub

    Private Sub BOX_Clean()

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()

        TextBox1.ReadOnly = False
        TextBox15.ReadOnly = False

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        BOX_Clean()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click '搜尋
        Dim Date_S As String = Microsoft.VisualBasic.Format(DateTimePicker1.Value, "#yyyy/MM/dd 00:00:00#")
        Dim Date_E As String = Microsoft.VisualBasic.Format(DateTimePicker2.Value, "#yyyy/MM/dd 23:59:59#")
        Dim DBCon As OleDbConnection
        DBCon = New OleDbConnection(Dut_Board)
        Dim cmd As OleDbCommand
        Dim Str As String = "Select * From AoD_Fail_Code Where Parts_ID Like '" & TextBox15.Text & "' ORDER BY In_DATE DESC"
 
        If CheckBox1.Checked = True And Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox15.Text)) > 0 Then
            Str = "Select * From AoD_Fail_Code Where In_Date Between " & Date_S & " and " & Date_E & "and Aod_No Like '" & TextBox1.Text & "' and Parts_ID Like '" & TextBox15.Text & "' ORDER BY In_DATE DESC"
        ElseIf CheckBox1.Checked = True And Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox15.Text)) = 0 Then
            Str = "Select * From AoD_Fail_Code Where In_Date Between " & Date_S & " and " & Date_E & "and Aod_No Like '" & TextBox1.Text & "' ORDER BY In_DATE DESC"
        ElseIf CheckBox1.Checked = True And Len(Trim(TextBox1.Text)) = 0 And Len(Trim(TextBox15.Text)) > 0 Then
            Str = "Select * From AoD_Fail_Code Where In_Date Between " & Date_S & " and " & Date_E & "and Parts_ID Like '" & TextBox15.Text & "' ORDER BY In_DATE DESC"
        ElseIf CheckBox1.Checked = False And Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox15.Text)) > 0 Then
            Str = "Select * From AoD_Fail_Code Where AoD_No Like '" & TextBox1.Text & "' and Parts_ID Like '" & TextBox15.Text & "' ORDER BY In_DATE DESC"
        ElseIf CheckBox1.Checked = False And Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox15.Text)) = 0 Then
            Str = "Select * From AoD_Fail_Code Where AoD_No Like '" & TextBox1.Text & "' ORDER BY In_DATE DESC"
        ElseIf CheckBox1.Checked = False And Len(Trim(TextBox1.Text)) = 0 And Len(Trim(TextBox15.Text)) > 0 Then
            Str = "Select * From AoD_Fail_Code Where Parts_ID Like '" & TextBox15.Text & "' ORDER BY In_DATE DESC"
        End If
        
        cmd = New OleDbCommand(Str, DBCon)
        DBCon.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        LB_Temp.Fill(DBST, "AoD_Temp")
        'DBST.Tables("AoD_Temp").Columns.Remove("ID")

        DBST.Tables("Aod_Temp").Columns("In_Date").SetOrdinal(1)
        DGView1.DataSource = DBST.Tables("AoD_Temp").DefaultView
        DGView1.Columns("ID").Visible = False
        DGView1.Columns("In_Date").HeaderText = "Date"
        DGView1.Columns("In_Date").DefaultCellStyle.Format = "yyyy/MM/dd"
        DBCon.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click 'UPDATE
        Dim Str As String
        Dim DBCon As OleDbConnection = New OleDbConnection(Dut_Board)
        Dim DBCmd As OleDbCommand

        If Trim(TextBox1.Text) = "" Or Trim(TextBox15.Text) = "" Then

            MsgBox("欄位有未填寫!!", MsgBoxStyle.Critical, "空值")

        ElseIf Trim(TextBox3.Text) = "" And Trim(TextBox4.Text) = "" And Trim(TextBox5.Text) = "" And Trim(TextBox6.Text) = "" And Trim(TextBox7.Text) = "" _
               And Trim(TextBox8.Text) = "" And Trim(TextBox9.Text) = "" And Trim(TextBox10.Text) = "" And Trim(TextBox11.Text) = "" And Trim(TextBox12.Text) = "" _
               And Trim(TextBox13.Text) = "" And Trim(TextBox14.Text) = "" And Trim(TextBox16.Text) = "" And Trim(TextBox17.Text) = "" And Trim(TextBox18.Text) = "" And Trim(TextBox19.Text) = "" And Trim(TextBox20.Text) = "" Then

            MsgBox("S1~S16 & Other issue 欄位不得全有未填寫!!", MsgBoxStyle.Critical, "空值")

        Else

            Try

                Str = "UPDATE AoD_Fail_Code SET In_Date = '" & Now & "', Aod_No ='" & Trim(TextBox1.Text) & "', Parts_ID ='" & Trim(TextBox15.Text) & "', Lot_No ='" & Trim(TextBox2.Text) & "', " & _
                                                "S01 = '" & Trim(TextBox3.Text) & "', S02 ='" & Trim(TextBox4.Text) & "', S03 = '" & Trim(TextBox5.Text) & "', S04 = '" & Trim(TextBox6.Text) & "',  " & _
                                                "S05 = '" & Trim(TextBox7.Text) & "', S06 = '" & Trim(TextBox8.Text) & "', S07 = '" & Trim(TextBox9.Text) & "', S08 = '" & Trim(TextBox10.Text) & "', " & _
                                                "S09 ='" & Trim(TextBox11.Text) & "', S10 = '" & Trim(TextBox12.Text) & "', S11 = '" & Trim(TextBox13.Text) & "', S12 = '" & Trim(TextBox14.Text) & "', " & _
                                                "S13 ='" & Trim(TextBox16.Text) & "', S14 = '" & Trim(TextBox17.Text) & "', S15 = '" & Trim(TextBox18.Text) & "', S16 = '" & Trim(TextBox19.Text) & "', Other_Issue = '" & Trim(TextBox20.Text) & "'" & _
                                                "WHERE ID Like '" & NUMB & "'"
                DBCon.Open()
                DBCmd = New OleDbCommand(Str, DBCon)
                DBCmd.ExecuteNonQuery()
                DBCon.Close()
                DBCmd.Dispose()

                TextBox1.ReadOnly = True
                TextBox15.ReadOnly = True
                MsgBox("Update更新完成~", MsgBoxStyle.Information, "Information")
                DB_Load()
                BOX_Clean()
                Button1.Enabled = False

            Catch ex As Exception
                MessageBox.Show(ex.Message)
                'MsgBox("重複Parts_ID", MsgBoxStyle.Exclamation, "重複性編號")
            Finally

               
            End Try

        End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click '報表
        SaveToExcel()
    End Sub

    Private Sub SaveToExcel()
        Dim excel As Microsoft.Office.Interop.Excel._Application = New Microsoft.Office.Interop.Excel.Application()
        Dim workbook As Microsoft.Office.Interop.Excel._Workbook = excel.Workbooks.Add(Type.Missing)
        Dim worksheet As Microsoft.Office.Interop.Excel._Worksheet = Nothing
        'Dim worksheet As Excel.Worksheet

        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        Dim arr As Array = Array.CreateInstance(GetType(String), DGView1.RowCount, DGView1.ColumnCount)
        Dim arr1 As Array = Array.CreateInstance(GetType(String), DGView1.RowCount, DGView1.ColumnCount)

        Try
            worksheet = workbook.ActiveSheet
            worksheet.Name = "AoD_Board"

            rowsTotal = DGView1.RowCount - 1
            colsTotal = DGView1.Columns.Count - 1

            For iC = 0 To colsTotal
                worksheet.Cells(1, iC + 1).Value = DGView1.Columns(iC).HeaderText
            Next

            For I = 0 To rowsTotal - 1


                For j = 0 To colsTotal 'old IS 1

                    'worksheet.Cells(I + 2, 1).value = Format(DataGridView1.Rows(I).Cells(0).Value, "yyyy/MM/dd")
                    'worksheet.Cells(I + 2, j + 1).value = DataGridView1.Rows(I).Cells(j).Value

                    If j = 1 Then
                        arr.SetValue(Format(DGView1.Rows(I).Cells(j).Value, "yyyy/MM/dd"), I, j)
                    Else
                        arr.SetValue(DGView1.Rows(I).Cells(j).Value.ToString, I, j)
                    End If

                Next j
            Next I


            '設置EXCEL位置 
            Dim A As Excel.Range
            A = worksheet.Range(worksheet.Cells(2, 1), worksheet.Cells(_DGView1.RowCount, _DGView1.ColumnCount))

            '陣列丟到excel 

            A.Value2 = arr

            worksheet.Range("A1:V1").Interior.Color = RGB(189, 215, 238)
            worksheet.Range("A1:V1").Font.Bold = True
            worksheet.Range("A1:V1").Font.Color = RGB(0, 0, 0)
            worksheet.UsedRange.Borders.LineStyle = 1
            worksheet.Columns.AutoFit()

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                workbook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            excel.Quit()
            workbook = Nothing
            excel = Nothing
        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '新增

        Dim Str As String
        Dim DBCon As OleDbConnection = New OleDbConnection(Dut_Board)
        Dim DBCmd As OleDbCommand

        If Trim(TextBox1.Text) = "" Or Trim(TextBox15.Text) = "" Then

            MsgBox("欄位有未填寫!!", MsgBoxStyle.Critical, "空值")

        ElseIf Trim(TextBox3.Text) = "" And Trim(TextBox4.Text) = "" And Trim(TextBox5.Text) = "" And Trim(TextBox6.Text) = "" And Trim(TextBox7.Text) = "" _
        And Trim(TextBox8.Text) = "" And Trim(TextBox9.Text) = "" And Trim(TextBox10.Text) = "" And Trim(TextBox11.Text) = "" And Trim(TextBox12.Text) = "" _
        And Trim(TextBox13.Text) = "" And Trim(TextBox14.Text) = "" And Trim(TextBox16.Text) = "" And Trim(TextBox17.Text) = "" And Trim(TextBox18.Text) = "" And Trim(TextBox19.Text) = "" And Trim(TextBox20.Text) = "" Then

            MsgBox("S1~S16 & Other issue 欄位不得全有未填寫!!", MsgBoxStyle.Critical, "空值")

        Else

            Try

                Str = "Insert Into AoD_Fail_Code(In_Date, Aod_No, Parts_ID, Lot_No, S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, Other_Issue )Values" & _
                                                   "( '" & Now & "' , '" & Trim(TextBox1.Text) & "', '" & Trim(TextBox15.Text) & "', '" & Trim(TextBox2.Text) & "', " & _
                                                   "'" & Trim(TextBox3.Text) & "','" & Trim(TextBox4.Text) & "','" & Trim(TextBox5.Text) & "', '" & Trim(TextBox6.Text) & "', " & _
                                                   "'" & Trim(TextBox7.Text) & "','" & Trim(TextBox8.Text) & "','" & Trim(TextBox9.Text) & "', '" & Trim(TextBox10.Text) & "', " & _
                                                   "'" & Trim(TextBox11.Text) & "','" & Trim(TextBox12.Text) & "','" & Trim(TextBox13.Text) & "', '" & Trim(TextBox14.Text) & "', " & _
                                                   "'" & Trim(TextBox16.Text) & "','" & Trim(TextBox17.Text) & "','" & Trim(TextBox18.Text) & "', '" & Trim(TextBox19.Text) & "', '" & Trim(TextBox20.Text) & "')"
                DBCon.Open()
                DBCmd = New OleDbCommand(Str, DBCon)
                DBCmd.ExecuteNonQuery()
                DBCon.Close()
                DBCmd.Dispose()
                MsgBox("新增Fail~", MsgBoxStyle.Information, "Information")
                DB_Load()
                BOX_Clean()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
                'MsgBox("重複Parts_ID", MsgBoxStyle.Exclamation, "重複性編號")
            Finally

               

            End Try

        End If

    End Sub

    Private Sub DGView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGView1.CellClick

        Dim row As DataGridViewRow = DGView1.CurrentRow
        '寫入變數
        NUMB = Val(row.Cells(0).Value.ToString())
        TextBox1.Text = row.Cells(2).Value.ToString()
        TextBox15.Text = row.Cells(3).Value.ToString()
        TextBox2.Text = row.Cells(4).Value.ToString()
        TextBox3.Text = row.Cells(5).Value.ToString()
        TextBox4.Text = row.Cells(6).Value.ToString()
        TextBox5.Text = row.Cells(7).Value.ToString()
        TextBox6.Text = row.Cells(8).Value.ToString()
        TextBox7.Text = row.Cells(9).Value.ToString()
        TextBox8.Text = row.Cells(10).Value.ToString()
        TextBox9.Text = row.Cells(11).Value.ToString()
        TextBox10.Text = row.Cells(12).Value.ToString()
        TextBox11.Text = row.Cells(13).Value.ToString()
        TextBox12.Text = row.Cells(14).Value.ToString()
        TextBox13.Text = row.Cells(15).Value.ToString()
        TextBox14.Text = row.Cells(16).Value.ToString()

        TextBox1.ReadOnly = True
        TextBox15.ReadOnly = True
        ' TextBox2.ReadOnly = True
        ' TextBox3.ReadOnly = True
        ' TextBox4.ReadOnly = True
        ' TextBox5.ReadOnly = True
        ' TextBox5.BackColor = Color.YellowGreen
        ' TextBox5.ForeColor = Color.White

        Button1.Enabled = True


    End Sub

  
End Class