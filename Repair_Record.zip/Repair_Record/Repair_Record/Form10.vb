﻿Imports System.Data.OleDb

Public Class Form10
    Dim Str As String
    Dim conn As OleDbConnection = New OleDbConnection(Componet_DataBase)
    'Dim K() As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '離開
        Me.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click '搜尋


        Str = "Select * From List_Table where Spec_Type Like '%' & '" & TextBox1.Text & "' & '%' "

        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()

        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()

        myDA.Fill(myDataSet, "MyTable")
        conn.Close()

        DataGridView1.DataSource = myDataSet.Tables("MyTable").DefaultView

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '確定

        Dim cmd As OleDbCommand
        Dim K() As String


        K = Split(COMP_Str, ";") ' 分割COMP_Str字串
        Dim n As Integer = 0
        Dim i As Integer
        For i = 0 To (CInt(K.Count / 7)) - 1 '12/6=2

            'Str = "Insert Into Receive_Table_V(Parts_ID, Customer, Family, Spil_No, Vendor_No, Kind, Type, Total_Qty,Received_QTY,Men_ID,Use_Date  )Values( '" & K((i * 10) + 1) & "' , '" & K((i * 10) + 2) & "' , '" & K((i * 10) + 3) & "' , '" & K((i * 10) + 4) & "' , '" & K((i * 10) + 5) & "' , '" & K((i * 10) + 6) & "' , '" & K((i * 10) + 7) & "' , '" & K((i * 10) + 8) & "' , '" & K((i * 10) + 9) & "' , '" & Register_ID & "' , '" & Now & "')"
            'Str = "Insert Into Consume_Table(ID, Consume_Qty, Consume_Man, Consume_Date, Consume_Customer, Consume_Family)Values('" & COMP_ID_V & "', '" & Received_QTY & "', '" & Register_ID & "' , '" & Now & "', '" & HFTV_Customer & "', '" & HFTV_Family & "')"
            Str = "Insert Into Consume_Table(ID, Consume_Qty, Consume_Man, Consume_Date, Consume_Customer, Consume_Family)Values('" & K((i * 7)) & "' , '" & K((i * 7) + 1) & "' , '" & K((i * 7) + 2) & "' , '" & K((i * 7) + 3) & "' , '" & K((i * 7) + 4) & "' , '" & K((i * 7) + 5) & "')"

            conn.Open()
            cmd = New OleDbCommand(Str, conn)
            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            Dim Comp_List As String = "Update List_Table set Qty = '" & K((i * 7) + 6) & "' where ID = " & CInt(K((i * 7))) & ""
            conn.Open()

            cmd = New OleDbCommand(Comp_List, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            n = n + 6
        Next
        conn = Nothing
        Me.Close()
    End Sub

    Private Sub DataGridView1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseDoubleClick

        Dim row As DataGridViewRow = DataGridView1.CurrentRow

        COMP_ID_V = (CDbl(row.Cells(0).Value.ToString()))
        COMP_SPIL_No_V = row.Cells(1).Value.ToString()
        COMP_Vendor_Name_V = row.Cells(2).Value.ToString()
        COMP_Vendor_No_V = row.Cells(3).Value.ToString()
        COMP_Customer_V = row.Cells(4).Value.ToString()
        COMP_Family_V = row.Cells(5).Value.ToString()
        COMP_Kind_V = row.Cells(6).Value.ToString()
        COMP_Type_V = row.Cells(7).Value.ToString()
        Comp_QTY = CInt(row.Cells(8).Value.ToString())
        COMP_Provider_V = row.Cells(9).Value.ToString()
        COMP_Creator_V = row.Cells(10).Value.ToString()
        COMP_Creator_Date_V = row.Cells(11).Value.ToString()
        COMP_Location_V = row.Cells(12).Value.ToString()
        COMP_Spare_Qty_V = CInt(row.Cells(13).Value.ToString())

        Form11.Show()

    End Sub

    Public Sub modify_comp_str()

        Dim cmd As OleDbCommand
        Dim K() As String

        K = Split(COMP_Str, ";") ' 分割COMP_Str字串
        Dim n As Integer = 0
        Dim i As Integer

        For i = 0 To (CInt(K.Count / 7)) - 1 '12/6=2

            Str = "Insert Into Consume_Table(ID, Consume_Qty, Consume_Man, Consume_Date, Consume_Customer, Consume_Family)Values('" & K((i * 7)) & "' , '" & K((i * 7) + 1) & "' , '" & K((i * 7) + 2) & "' , '" & K((i * 7) + 3) & "' , '" & K((i * 7) + 4) & "' , '" & K((i * 7) + 5) & "')"

            conn.Open()
            cmd = New OleDbCommand(Str, conn)
            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            ' conn.Close()

            Dim Comp_List As String = "Update List_Table set Qty = '" & K((i * 7) + 6) & "' where ID = " & CInt(K((i * 7))) & ""
            ' conn.Open()
            cmd = New OleDbCommand(Comp_List, conn)
            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()
            n = n + 6
        Next


    End Sub
  
End Class
