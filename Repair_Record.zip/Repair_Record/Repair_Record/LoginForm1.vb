﻿Imports System.Data.OleDb
Imports ADODB

Public Class LoginForm1
    Dim Access As String = Register_Database
    Dim myCon As New ADODB.Connection
    Dim myRst As New ADODB.Recordset
    Dim IP_Addres, IP As String

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If txt_User.Text = "" Or txt_Pass.Text = "" Then
            MessageBox.Show("使用者工號 或 密碼 不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        Else
            myCon = New Connection
            myCon.Open(Access)
            myRst = New Recordset
            Dim strql As String = "Select * from" & UserN & "where Name_ID like '" & txt_User.Text & "' and Name_P like '" & txt_Pass.Text & "' "
            myRst = myCon.Execute(strql)
            If myRst.EOF = True Then
                MessageBox.Show(" 使用者名稱或密碼錯誤 ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                myCon.Close()
                txt_Pass.Text = ""
            Else

                '登入帳號權限及部門
                If (myRst.Fields("Name_F").Value.ToString = "USER" And myRst.Fields("Name_D").Value.ToString = "LB_HS") = True Then

                    User_Unit = "LB_HS"
                    H_Z_DBCon = HS_LB_Database

                ElseIf (myRst.Fields("Name_F").Value.ToString Like "USER" And myRst.Fields("Name_D").Value.ToString Like "LB_ZK") = True Then

                    User_Unit = "LB_ZK"
                    H_Z_DBCon = ZK_LB_Database

                ElseIf (myRst.Fields("Name_F").Value.ToString = "ADMIN" And myRst.Fields("Name_D").Value.ToString = "LB_HS") = True Then

                    User_Unit = "LB_ADMIN"
                    H_Z_DBCon = HS_LB_Database

                ElseIf (myRst.Fields("Name_F").Value.ToString Like "USER" And myRst.Fields("Name_D").Value.ToString Like "CP") = True Then

                    User_Unit = "CP"

                ElseIf (myRst.Fields("Name_F").Value.ToString Like "USER" And myRst.Fields("Name_D").Value.ToString Like "Tooling") = True Then

                    User_Unit = "Tooling"

                ElseIf (myRst.Fields("Name_F").Value.ToString = "ADMIN" And myRst.Fields("Name_D").Value.ToString = "Modify") = True Then

                    User_Unit = "ADMIN"

                End If

                IP_Input()

                User_ID = txt_User.Text '登錄者ID
                '記錄
                Dim Str_IP As String = "Insert Into" & Register_Date_Table & "(User_ID, IP_Addres, Version, Inster_Date)Values" & _
                                       "( '" & txt_User.Text & "','" & IP_Addres & "','" & Version & "', '" & Now & "')"

                Dim conn As OleDbConnection = New OleDbConnection(Access)
                conn.Open()
                Dim cmd As OleDbCommand = New OleDbCommand(Str_IP, conn)

                '執行資料庫指令OleDbCommand
                cmd.ExecuteNonQuery()
                conn.Close()
                myCon.Close()
                Me.Hide()
                'Home_Screen.Show() '主畫面
                Home_Screen.Show()

            End If
        End If

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoginForm2.Show()
        Me.Hide()
    End Sub

    Private Sub IP_Input()
        Dim HostName As String = System.Net.Dns.GetHostName

        For Each item As System.Net.IPAddress In System.Net.Dns.GetHostEntry(HostName).AddressList
            IP = item.ToString
        Next

        IP_Addres = IP

    End Sub

    Private Sub LoginForm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        myCon = New Connection
        myCon.Open(Access)
        myRst = New Recordset

        Dim strql As String = "Select * from" & Ver_Table & "where Ver like '" & Version & "'"

        myRst = myCon.Execute(strql)

        If myRst.EOF = True Then
            MessageBox.Show(" 此版本為舊版本，請更新! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            myCon.Close()
            Me.Close()
        Else : myCon.Close()
        End If


    End Sub

End Class

