﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports ADODB

Public Class Inquire

    Dim conn As OleDbConnection
    'Dim sql As String
    Dim Str As String


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '沒用到
        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset
        Dim excelApp As Excel.Application = New Excel.ApplicationClass()
        Dim NewWorksheet As Excel.Worksheet
        Dim i As Integer

        Dim Date_S As String = Microsoft.VisualBasic.Format(DateTimePicker1.Value, "#yyyy/MM/dd 00:00:00#")
        Dim Date_E As String = Microsoft.VisualBasic.Format(DateTimePicker2.Value, "#yyyy/MM/dd 23:59:59#")

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        End If


        If CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False Then '0000
            MessageBox.Show("請輸入條件", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf CheckBox3.Checked = True And Trim(TextBox2.Text) = "" Then
            MessageBox.Show("ID未輸入", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf CheckBox2.Checked = True And Trim(TextBox1.Text) = "" Then
            MessageBox.Show("型號未輸入", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True Then '0001 
            Str = "Select * from Repair_Done_List_V where Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False Then '0010 
            Str = "Select * from Repair_Done_List_V where Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = True Then '0011
            Str = "Select * from Repair_Done_List_V where Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False Then '0100
            Str = "Select * from Repair_Done_List_V where Family Like '" & TextBox1.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = True Then '0101
            Str = "Select * from Repair_Done_List_V where Family Like '" & TextBox1.Text & "%'  and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = False Then '0110
            Str = "Select * from Repair_Done_List_V where Family Like '" & TextBox1.Text & "%' and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = True Then '0111
            Str = "Select * from Repair_Done_List_V where Family Like '" & TextBox1.Text & "%' and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False Then '1000
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & "and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True Then '1001
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & "and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False Then '1010
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = True Then '1011
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False Then '1100
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = True Then '1101
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%' and Finish_Close Like '%'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = False Then '1110
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%' and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like 'Y'"
        ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = True Then '1111
            Str = "Select * from Repair_Done_List_V where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%' and Parts_ID Like '" & TextBox2.Text & "%' and Finish_Close Like '%'"

        End If

        myCon = New Connection
        myCon.Open(H_Z_DBCon)

        myRst = New Recordset
        myRst = myCon.Execute(Str)


        If myRst.EOF = True Then

            MessageBox.Show(" No Data ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            myCon.Close()
        Else

            excelApp.DisplayAlerts = False ''停用警告訊息
            excelApp.Visible = False '設置EXCEL對象可見

            excelApp.Workbooks.Add()

            NewWorksheet = excelApp.Application.Sheets(1)

            NewWorksheet.Range("A1:X1").Interior.Color = RGB(0, 128, 0)
            NewWorksheet.Range("A1:X1").Font.Bold = True
            NewWorksheet.Range("A1:X1").Font.Color = RGB(255, 255, 255)
            NewWorksheet.Range("A1").Value = "Down_Date"
            NewWorksheet.Range("B1").Value = "Repair_Date_ST"
            NewWorksheet.Range("C1").Value = "Repair_Date_END"

            NewWorksheet.Range("D1").Value = "Parts_ID"
            NewWorksheet.Range("E1").Value = "Tester_ID"
            NewWorksheet.Range("F1").Value = "Customer"
            NewWorksheet.Range("G1").Value = "Family"
            NewWorksheet.Range("H1").Value = "Device"
            NewWorksheet.Range("I1").Value = "PGM"

            If USER_UNIT = "LB_HS" Or USER_UNIT = "LB_ZK" Or USER_UNIT = "LB_ADMIN" Then
                NewWorksheet.Range("J1").Value = "Test_Mode"
            ElseIf USER_UNIT = "CP" Then
                NewWorksheet.Range("J1").Value = "Site_Qty"
            End If

            NewWorksheet.Range("K1").Value = "Stage"
            NewWorksheet.Range("L1").Value = "Fail_Site"
            NewWorksheet.Range("M1").Value = "Fail_Bin"
            NewWorksheet.Range("N1").Value = "Fail_Item"
            NewWorksheet.Range("O1").Value = "Send_Man"
            NewWorksheet.Range("P1").Value = "Fail_Name"
            NewWorksheet.Range("Q1").Value = "Action"
            NewWorksheet.Range("R1").Value = "Root_Cause"
            NewWorksheet.Range("S1").Value = "Change_Parts"
            NewWorksheet.Range("T1").Value = "Attribute"
            NewWorksheet.Range("U1").Value = "Final_Result"
            NewWorksheet.Range("V1").Value = "Now_Status"
            NewWorksheet.Range("W1").Value = "Total_Time"
            NewWorksheet.Range("X1").Value = "Repair_Man"
            i = 2

            Do While Not myRst.EOF


                NewWorksheet.Cells(i, 1) = Microsoft.VisualBasic.Format(myRst.Fields("Date_Time").Value, "yyyy/MM/dd")
                NewWorksheet.Cells(i, 2) = myRst.Fields("Repair_Date_ST").Value
                NewWorksheet.Cells(i, 3) = myRst.Fields("Repair_Date_END").Value

                If USER_UNIT = "LB_HS" Or USER_UNIT = "LB_ZK" Or USER_UNIT = "LB_ADMIN" Then
                    NewWorksheet.Cells(i, 4) = myRst.Fields("Parts_ID").Value
                ElseIf USER_UNIT = "CP" Then
                    NewWorksheet.Cells(i, 4) = myRst.Fields("Parts_ID").Value & "-" & myRst.Fields("ProbeHead_ID").Value
                End If

                NewWorksheet.Cells(i, 5) = myRst.Fields("Tester_ID").Value
                NewWorksheet.Cells(i, 6) = myRst.Fields("Customer").Value
                NewWorksheet.Cells(i, 7) = myRst.Fields("Family").Value
                NewWorksheet.Cells(i, 8) = myRst.Fields("Device").Value
                NewWorksheet.Cells(i, 9) = myRst.Fields("PGM").Value
                NewWorksheet.Cells(i, 10) = myRst.Fields("Test_Mode").Value
                NewWorksheet.Cells(i, 11) = myRst.Fields("Stage").Value
                NewWorksheet.Cells(i, 12) = myRst.Fields("Fail_Site").Value
                NewWorksheet.Cells(i, 13) = myRst.Fields("Fail_Bin").Value
                NewWorksheet.Cells(i, 14) = myRst.Fields("Fail_Item").Value
                NewWorksheet.Cells(i, 15) = myRst.Fields("Send_Man").Value
                NewWorksheet.Cells(i, 16) = myRst.Fields("Fail_Name").Value
                NewWorksheet.Cells(i, 17) = myRst.Fields("Action_R").Value
                NewWorksheet.Cells(i, 18) = myRst.Fields("Root_Cause").Value
                NewWorksheet.Cells(i, 19) = myRst.Fields("Change_Parts").Value
                NewWorksheet.Cells(i, 20) = myRst.Fields("Attribute").Value
                NewWorksheet.Cells(i, 21) = myRst.Fields("Final_Result").Value
                NewWorksheet.Cells(i, 22) = myRst.Fields("Now_Status").Value
                NewWorksheet.Cells(i, 23) = myRst.Fields("Total_Time").Value
                NewWorksheet.Cells(i, 24) = myRst.Fields("Repair_Man").Value

                myRst.MoveNext()
                i = i + 1

                NewWorksheet.UsedRange.Borders.LineStyle = 1
                NewWorksheet.Columns.AutoFit()

            Loop

            NewWorksheet.Name = "維修完成List"
            excelApp.ActiveWorkbook.SaveAs("D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "維修完成List.xlsx")
            excelApp.DisplayAlerts = True
            excelApp.Quit()

            myCon.Close()
            MessageBox.Show("匯出成功，查看D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "維修完成List.xlsx", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If

    End Sub

    Private Sub Inquire_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
    End Sub

    Private Sub EXT_Load()
        Dim Date_S As String = Microsoft.VisualBasic.Format(DateTimePicker1.Value, "#yyyy/MM/dd 00:00:00#")
        Dim Date_E As String = Microsoft.VisualBasic.Format(DateTimePicker2.Value, "#yyyy/MM/dd 23:59:59#")

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        End If

        Try

            If CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False Then '0000
                MessageBox.Show("請輸入條件", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            ElseIf CheckBox3.Checked = True And Trim(TextBox2.Text) = "" Then
                MessageBox.Show("ID未輸入", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            ElseIf CheckBox2.Checked = True And Trim(TextBox1.Text) = "" Then
                MessageBox.Show("型號未輸入", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True Then '0001 
                Str = "Select * from" & Repair_Done_List_V_Table & "where Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False Then '0010 
                Str = "Select * from" & Repair_Done_List_V_Table & "where Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close = 'Y' order by Repair_Date_ST DESC"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = True Then '0011
                Str = "Select * from" & Repair_Done_List_V_Table & "where Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False Then '0100
                Str = "Select * from" & Repair_Done_List_V_Table & "where Family Like '" & TextBox1.Text & "%" & "' and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = True Then '0101
                Str = "Select * from" & Repair_Done_List_V_Table & "where Family Like '" & TextBox1.Text & "%" & "'  and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = False Then '0110
                Str = "Select * from" & Repair_Done_List_V_Table & "where Family Like '" & TextBox1.Text & "%' and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = True Then '0111
                Str = "Select * from" & Repair_Done_List_V_Table & "where Family Like '" & TextBox1.Text & "%" & "' and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False Then '1000
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & "and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True Then '1001
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & "and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False Then '1010
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = True Then '1011
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False Then '1100
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%" & "' and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = True Then '1101
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%" & "' and Finish_Close Like '%' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = False Then '1110
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%" & "' and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like 'Y' order by Repair_Date_ST Desc"
            ElseIf CheckBox1.Checked = True And CheckBox2.Checked = True And CheckBox3.Checked = True And CheckBox4.Checked = True Then '1111
                Str = "Select * from" & Repair_Done_List_V_Table & "where Repair_Date_ST Between " & Date_S & " and " & Date_E & " and Family Like '" & TextBox1.Text & "%" & "' and Parts_ID Like '" & TextBox2.Text & "%" & "' and Finish_Close Like '%' order by Repair_Date_ST Desc"

            End If

            '==============
            conn = New OleDbConnection(H_Z_DBCon)

            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
            conn.Open()
            Dim EXT_Table As OleDbDataAdapter = New OleDbDataAdapter(cmd)

            DBST = New DataSet()
            EXT_Table.Fill(DBST, "LB_Done_Table_Temp")

            DBST.Tables("LB_Done_Table_Temp").Columns("Fail_Reason").SetOrdinal(12)
            DataGridView1.DataSource = DBST.Tables("LB_Done_Table_Temp").DefaultView

            DataGridView1.Columns.Remove("ID")
            DataGridView1.Columns.Remove("Finish_Close")
            DataGridView1.Columns.Remove("ID_Close")
            DataGridView1.Columns.Remove("LB_VENDOR")
            ' DataGridView1.Columns.RemoveAt(0) '刪除欄位
            'DataGridView1.Columns("ID").Visible = False '0

            DataGridView1.Columns("Date_Time").HeaderText = "Down_Date"
            DataGridView1.Columns("Action_R").HeaderText = "Action"
            ' DataGridView1.Columns("Tester_ID").HeaderText = "Tester"
            DataGridView1.Columns("Date_Time").DefaultCellStyle.Format = "yyyy/MM/dd"

            'DataGridView1.Columns("DownTime").Width = 130
            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

        End Try

        Exit Sub

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        EXT_Load()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'EXCEL_OUT()
        SaveToExcel()

    End Sub

    Private Sub SaveToExcel()
        Dim excel As Microsoft.Office.Interop.Excel._Application = New Microsoft.Office.Interop.Excel.Application()
        Dim workbook As Microsoft.Office.Interop.Excel._Workbook = excel.Workbooks.Add(Type.Missing)
        Dim worksheet As Microsoft.Office.Interop.Excel._Worksheet = Nothing
        'Dim worksheet As Excel.Worksheet

        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        Dim arr As Array = Array.CreateInstance(GetType(String), DataGridView1.RowCount, DataGridView1.ColumnCount)
        Dim arr1 As Array = Array.CreateInstance(GetType(String), DataGridView1.RowCount, DataGridView1.ColumnCount)

        Try
            worksheet = workbook.ActiveSheet
            worksheet.Name = "維修完成LIST"

            rowsTotal = DataGridView1.RowCount - 1
            colsTotal = DataGridView1.Columns.Count - 1

            For iC = 0 To colsTotal
                worksheet.Cells(1, iC + 1).Value = DataGridView1.Columns(iC).HeaderText
            Next

            For I = 0 To rowsTotal - 1


                For j = 0 To colsTotal 'old IS 1

                    'worksheet.Cells(I + 2, 1).value = Format(DataGridView1.Rows(I).Cells(0).Value, "yyyy/MM/dd")
                    'worksheet.Cells(I + 2, j + 1).value = DataGridView1.Rows(I).Cells(j).Value

                    If j = 0 Then
                        arr.SetValue(Format(DataGridView1.Rows(I).Cells(j).Value, "yyyy/MM/dd"), I, j)
                    Else
                        arr.SetValue(DataGridView1.Rows(I).Cells(j).Value.ToString, I, j)
                    End If

                Next j
            Next I


            '設置EXCEL位置 
            Dim A As Excel.Range
            A = worksheet.Range(worksheet.Cells(2, 1), worksheet.Cells(_DataGridView1.RowCount, _DataGridView1.ColumnCount))

            '陣列丟到excel 

            A.Value2 = arr

            worksheet.Range("A1:Y1").Interior.Color = RGB(0, 128, 0)
            worksheet.Range("A1:Y1").Font.Bold = True
            worksheet.Range("A1:Y1").Font.Color = RGB(255, 255, 255)
            worksheet.UsedRange.Borders.LineStyle = 1
            worksheet.Columns.AutoFit()

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                workbook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            excel.Quit()
            workbook = Nothing
            excel = Nothing
        End Try

    End Sub


End Class
