﻿Imports System.Data.OleDb
Imports ADODB

Public Class Form17
    Dim sql As String = Componet_DataBase
    Dim Str As String
    Dim conn As OleDbConnection = New OleDbConnection(Sql)
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        Dim k As Integer

        k = Comp_QTY - TextBox1.Text

        If TextBox1.Text > Comp_QTY Then
            MessageBox.Show(" 領用數量不得大於目前數量.. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else

            Str = "Insert Into Consume_Table(ID, Consume_Qty, Consume_Man, Consume_Date)Values( '" & Comp_ID & "' , '" & TextBox1.Text & "' , '" & User_ID & "' , '" & Now & "' )"
            ' Dim conn As OleDbConnection = New OleDbConnection(sql)
            conn.Open()

            cmd = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            Str = "Update List_Table set QTY = '" & k & "' where ID like " & Comp_ID & ""
            ' Dim conn As OleDbConnection = New OleDbConnection(sql)
            conn.Open()

            cmd = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            MessageBox.Show(" Done.. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            TextBox1.Text = ""

            Component_Control.Button4.PerformClick()
            Component_Control.Comp_ReLoard()
        End If
        Me.Close()

    End Sub

   
End Class