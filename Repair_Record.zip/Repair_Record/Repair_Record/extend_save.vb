﻿Imports System.Data.OleDb

Public Class extend_save
    Private Comp As New Form10
    Dim conn As OleDbConnection = New OleDbConnection(H_Z_DBCon)
    Dim Str As String
    Dim Verify As String = "C" '完工 指標
    Dim RFL_Finish_Close As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '暫存
        ' Close_Table = "1" '判斷Close 按鈕

        Dim Total_Time As Long
        Total_Time = DateDiff(DateInterval.Minute, R_Satrt_Time.Value, R_End_Time.Value)

        If Trim(txt_FailName.Text) = "" Or Trim(txt_Action.Text) = "" Or Trim(txt_RootCause.Text) = "" Or Trim(Cob_Attribute.Text) = "" Or Trim(txt_RepairManID.Text) = "" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("欄位不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf R_Satrt_Time.Value >= R_End_Time.Value Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("結束時間不得小於起始時間!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Cob_NowStatus.Text = "已結案" Then
            ' Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Now_Status 已結案，不得未結案存檔!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        Else
            Close_Table = "1" '判斷Close 按鈕
            RFL_Finish_Close = "N"

            Dim U_R_Temp As String = " Update" & Repair_Fill_List_Table & "set Repair_Date_ST = '" & R_Satrt_Time.Value & "', Repair_Date_END = '" & R_End_Time.Value & "', Repair_Man = '" & txt_RepairManID.Text & "', Fail_Name ='" & txt_FailName.Text & "', Action_R = '" & txt_Action.Text & "', Root_Cause = '" & txt_RootCause.Text & "', Change_Parts = '" & txt_ChangeParts.Text & "', Attribute = '" & Cob_Attribute.Text & "', Final_Result = '" & Cob_FinalResult.Text & "', Now_Status = '" & Cob_NowStatus.Text & "', Total_Time = '" & Total_Time & "',  Finish_Close = '" & RFL_Finish_Close & "' where ID = " & RV_ID & " AND ID_Close = 'N'"

            conn.Open()
            Dim cmd As OleDbCommand = New OleDbCommand(U_R_Temp, conn)
            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()


            Comp.modify_comp_str() '扣除元件數量


            '顯示成功新增記錄的訊息()
            MessageBox.Show("儲存完成", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.Close()
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '完工
        'Close_Table = "1" '判斷Close 按鈕

        Dim Total_Time As Long
        Total_Time = DateDiff(DateInterval.Minute, R_Satrt_Time.Value, R_End_Time.Value)

      
        If Trim(txt_FailName.Text) = "" Or Trim(txt_Action.Text) = "" Or Trim(txt_RootCause.Text) = "" Or Trim(Cob_Attribute.Text) = "" Or Trim(txt_RepairManID.Text) = "" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("欄位不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Microsoft.VisualBasic.Right(Cob_FinalResult.Text, 4) <> "Pass" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Final_Result 非 PASS!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Cob_NowStatus.Text <> "已結案" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Now_Status 非 已結案!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf R_Satrt_Time.Value >= R_End_Time.Value Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("結束時間不得小於起始時間!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        Else
            Close_Table = "1" '判斷Close 按鈕

            RFL_Finish_Close = "Y"

            Dim U_R_Temp As String = " Update" & Repair_Fill_List_Table & "set Repair_Date_ST = '" & R_Satrt_Time.Value & "', Repair_Date_END = '" & R_End_Time.Value & "', Repair_Man = '" & txt_RepairManID.Text & "', Fail_Name ='" & txt_FailName.Text & "', Action_R = '" & txt_Action.Text & "', Root_Cause = '" & txt_RootCause.Text & "', Change_Parts = '" & txt_ChangeParts.Text & "', Attribute = '" & Cob_Attribute.Text & "', Final_Result = '" & Cob_FinalResult.Text & "', Now_Status = '" & Cob_NowStatus.Text & "', Total_Time = '" & Total_Time & "',  Finish_Close = '" & RFL_Finish_Close & "', ID_Close = 'Y' where ID = " & RV_ID & " AND ID_Close = 'N'"

            conn.Open()

            Dim cmd1 As OleDbCommand = New OleDbCommand(U_R_Temp, conn)

            cmd1.ExecuteNonQuery()
            'conn.Close()

            Str = " Update" & Fill_Data & "set Verify = '" & Verify & "' where ID = " & RV_ID & ""
            'conn.Open()
            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            Comp.modify_comp_str() '扣除元件數量

            '顯示成功新增記錄的訊息()
            MessageBox.Show("完成維修(DONE)", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.Close()
        End If



    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        On Error Resume Next
        Dim P_id As String
        Dim k As Integer = CInt(DataGridView1.CurrentCell().RowIndex.ToString)
        Dim attri As String = CStr(DataGridView1.Rows(k).Cells(0).Value)
        P_id = Microsoft.VisualBasic.Left(Lab_PartsID.Text, 4) & "%"

        STR = "Select * from" & Repair_Done_List_V_Table & "where Parts_ID Like '" & P_id & "' and Final_Result Like '%Pass' and Fail_Bin like '" & RV_FailBin & "' and Attribute Like '" & attri & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(STR, conn)
        conn.Open()

        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()

        myDA.Fill(myDataSet, "MyTable")
        DataGridView2.DataSource = myDataSet.Tables("MyTable").DefaultView


        DataGridView2.Columns("ID").Visible = False
        DataGridView2.Columns("Date_Time").Visible = False
        DataGridView2.Columns("Repair_Date_ST").Visible = False
        DataGridView2.Columns("Repair_Date_END").Visible = False
        DataGridView2.Columns("Parts_ID").Visible = True
        DataGridView2.Columns("Tester_ID").Visible = True
        DataGridView2.Columns("Customer").Visible = False
        DataGridView2.Columns("Family").Visible = False
        DataGridView2.Columns("Test_Mode").Visible = True
        DataGridView2.Columns("Send_Man").Visible = False
        'DataGridView2.Columns("Repair_Man").Visible = False
        DataGridView2.Columns("Fail_Item").Visible = False
        DataGridView2.Columns("Fail_Site").Visible = True
        DataGridView2.Columns("Fail_Bin").Visible = False
        DataGridView2.Columns("Repair_Site").Visible = False
        DataGridView2.Columns("Repair_Bin").Visible = False
        DataGridView2.Columns("Fail_Name").Visible = False
        DataGridView2.Columns("Action_R").Visible = False
        DataGridView2.Columns("Root_Cause").Visible = True
        DataGridView2.Columns("Change_Parts").Visible = True
        DataGridView2.Columns("Attribute").Visible = True
        DataGridView2.Columns("Final_Result").Visible = False
        DataGridView2.Columns("Now_Status").Visible = False
        DataGridView2.Columns("Total_Time").Visible = False
        DataGridView2.Columns("Finish_Close").Visible = False

        conn.Close()

    End Sub

    Private Sub extend_save_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Close_Table = "1" Then '有存檔時執行

            HS_LoadBoard.Button6.PerformClick() ' 更新畫面

        Else

            Dim cmd As OleDbCommand
            Str = "Delete From" & Repair_Fill_List_Table & "Where ID Like " & RV_ID & " and ID_Close = 'N'"
            conn.Open()
            cmd = New OleDbCommand(Str, conn)
            cmd.ExecuteNonQuery()
            conn.Close()

            Str = " Update" & Repair_Fill_List_Table & "set ID_Close = 'N' where ID = " & RV_ID & " and ID_N = " & RFL_ID_N & " -1 and ID_Close = 'Y'"
            conn.Open()
            cmd = New OleDbCommand(Str, conn)
            cmd.ExecuteNonQuery()
            conn.Close()

            If Close_Table = "0" Then
                Str = " Update" & Fill_Data & "set Verify = 'N' where ID = " & RV_ID & ""
                conn.Open()
                cmd = New OleDbCommand(Str, conn)
                '執行資料庫指令OleDbCommand
                cmd.ExecuteNonQuery()
                conn.Close()
            End If
            HS_LoadBoard.Button6.PerformClick() ' 更新畫面
        End If

        conn.Dispose()
    End Sub

    Private Sub Input_Table1()
        'Table input

        Str = "Select DISTINCT Item from Attribute"
        Dim adp As OleDbDataAdapter = New OleDbDataAdapter(Str, conn)
        conn.Open()
        Dim set1 As DataSet = New DataSet
        adp.Fill(set1, "#1")
        Cob_Attribute.DataSource = set1.Tables("#1")
        Cob_Attribute.ValueMember = "Item"
        conn.Close()
        adp = Nothing
        Str = "Select DISTINCT Item from Now_Status"
        Dim adp1 As OleDbDataAdapter = New OleDbDataAdapter(Str, conn)
        conn.Open()
        Dim Now_Status_set As DataSet = New DataSet
        adp1.Fill(Now_Status_set, "#1")
        Cob_NowStatus.DataSource = Now_Status_set.Tables("#1")
        Cob_NowStatus.ValueMember = "Item"
        conn.Close()
        adp1 = Nothing

        Str = "Select DISTINCT Man_ID from Man_List"
        Dim adp2 As OleDbDataAdapter = New OleDbDataAdapter(Str, conn)
        conn.Open()
        Dim Repair_Man_ID_Set As DataSet = New DataSet
        adp2.Fill(Repair_Man_ID_Set, "#1")
        txt_RepairManID.DataSource = Repair_Man_ID_Set.Tables("#1")
        txt_RepairManID.ValueMember = "Man_ID"
        conn.Close()
        adp2 = Nothing

        Cob_FinalResult.Items.Add("Online Pass")
        Cob_FinalResult.Items.Add("Online Fail")
        Cob_FinalResult.Items.Add("Offline Pass")
        Cob_FinalResult.Items.Add("Offline Fail")

    End Sub

    Private Sub txt_ChangeParts_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_ChangeParts.MouseDoubleClick '更換元件欄位
        txt_ChangeParts.Text = ""
        Change_Parts_List = ""
        COMP_Str = ""
        Form10.Show()
    End Sub


    Private Sub Cob_Attribute_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cob_Attribute.SelectedIndexChanged


    End Sub

    Private Sub Cob_NowStatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cob_NowStatus.SelectedIndexChanged


        If Cob_NowStatus.Text = "待維修" Then

            Cob_Attribute.SelectedIndex = 0

            Cob_Attribute.Enabled = False
        Else

            Cob_Attribute.Enabled = True


        End If



    End Sub

    Private Sub Cob_Attribute_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cob_Attribute.SelectedValueChanged

        If Arr_Attribute(Cob_Attribute.SelectedIndex) = True Then '2021/8/9 NEW ADD

            txt_ChangeParts.Enabled = True
        Else

            txt_ChangeParts.Enabled = False
        End If

    End Sub
End Class