﻿Imports System.Data.OleDb


Public Class Home_Screen
    Dim Access_Update As Class1_Access

    Private Sub AppionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AppionToolStripMenuItem.Click
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True
            Appion.MdiParent = Me

            If User_Unit = "LB_HS" Or User_Unit = "LB_ZK" Or User_Unit = "LB_ADMIN" Then
                Appion.Cob_Unit.Items.Add("")
                Appion.Cob_Unit.Items.Add("L/B")

            ElseIf User_Unit = "CP" Or User_Unit = "LB_ADMIN" Then
                Appion.Cob_Unit.Items.Add("")
                Appion.Cob_Unit.Items.Add("CP")

            End If

            Appion.Show()
        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    Private Sub ReceiveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReceiveToolStripMenuItem.Click

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True
            HS_LoadBoard.MdiParent = Me

            HS_LoadBoard.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default


    End Sub

    Private Sub ComponentControlToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComponentControlToolStripMenuItem.Click
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            Component_Control.MdiParent = Me

            Component_Control.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default


    End Sub

    Private Sub Home_Screen_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        End

    End Sub

    Private Sub DutBoardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DutBoardToolStripMenuItem.Click

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            Dutboard.MdiParent = Me

            Dutboard.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    Private Sub EditFailCodeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditFailCodeToolStripMenuItem.Click
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            DutBoard_Fail_Code.MdiParent = Me

            DutBoard_Fail_Code.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
    End Sub

    Private Sub UpadteDBUToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpadteDBUToolStripMenuItem.Click

        Dim DB As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
                                      "Data Source=\\NAS27\LB-Repair-Room\DataBase\PMS_Database_Auto_LB_CP.accdb;" & _
                                      "User Id=Admin;Jet OLEDB:Database Password= ;Persist Security Info=True"
        Dim DBCon As OleDbConnection = New OleDbConnection(DB)


        Dim Str As String = "delete * from PLB_List"
        Dim Str1 As String = "delete * from PLB_Borrow_List"

        Dim Str2 As String = "INSERT INTO PLB_List(PARTS_ID, FAMILY, CUSTOMER, LB_VENDOR, TEST_MODE, STATUS, SITE_NO) " & _
                             "SELECT PLB_List_V.PARTS_ID, PLB_List_V.FAMILY, PLB_List_V.CUSTOMER, PLB_List_V.LB_VENDOR, PLB_List_V.TEST_MODE, PLB_List_V.STATUS, PLB_List_V.SITE_NO " & _
                             "FROM PLB_List RIGHT JOIN PLB_List_V ON PLB_List.PARTS_ID = PLB_List_V.PARTS_ID " & _
                             "WHERE (((PLB_List.PARTS_ID) Is Null))"

        Dim Str3 As String = "INSERT INTO PLB_List_RV ( PARTS_ID, FAMILY, CUSTOMER, LB_VENDOR, TEST_MODE, STATUS, SITE_NO) " & _
                             "SELECT PLB_List_V.PARTS_ID, PLB_List_V.FAMILY, PLB_List_V.CUSTOMER, PLB_List_V.LB_VENDOR, PLB_List_V.TEST_MODE, PLB_List_V.STATUS, PLB_List_V.SITE_NO " & _
                             "FROM PLB_List_V LEFT JOIN PLB_List_RV ON PLB_List_V.PARTS_ID = PLB_List_RV.PARTS_ID "

        Dim Str4 As String = "INSERT INTO PLB_Borrow_List ( PARTS_NAME, PARTS_ID, B_TESTER, B_FAMILY, B_DEVICE, B_PGM, B_STATUS, B_STAGE, B_DATE, R_DATE, RETURN_TMP, SITE_NO) " & _
                             "SELECT PLB_Borrow_List_V.PARTS_NAME, PLB_Borrow_List_V.PARTS_ID, PLB_Borrow_List_V.B_TESTER, PLB_Borrow_List_V.B_FAMILY, PLB_Borrow_List_V.B_DEVICE, PLB_Borrow_List_V.B_PGM, PLB_Borrow_List_V.B_STATUS, PLB_Borrow_List_V.B_STAGE, PLB_Borrow_List_V.B_DATE, PLB_Borrow_List_V.R_DATE, PLB_Borrow_List_V.RETURN_TMP, PLB_Borrow_List_V.SITE_NO " & _
                             "FROM PLB_Borrow_List_V LEFT JOIN PLB_Borrow_List ON PLB_Borrow_List_V.PARTS_ID = PLB_Borrow_List.PARTS_ID "

        Dim Str5 As String = "UPDATE PLB_List INNER JOIN PLB_List_RV ON PLB_List.PARTS_ID = PLB_List_RV.PARTS_ID SET PLB_List.STATUS = [PLB_List_RV].[STATUS] " & _
                             "WHERE (((PLB_List_RV.STATUS)<>[PLB_LIST].[STATUS]))"

        Dim DBCom As OleDbCommand
        DBCon.Open()
        DBCom = New OleDbCommand(Str, DBCon)
        DBCom.ExecuteNonQuery()
        DBCom = New OleDbCommand(Str1, DBCon)
        DBCom.ExecuteNonQuery()
        DBCom = New OleDbCommand(Str2, DBCon)
        DBCom.ExecuteNonQuery()
        DBCom = New OleDbCommand(Str3, DBCon)
        DBCom.ExecuteNonQuery()
        DBCom = New OleDbCommand(Str4, DBCon)
        DBCom.ExecuteNonQuery()
        DBCom = New OleDbCommand(Str5, DBCon)
        DBCom.ExecuteNonQuery()

        DBCom.Dispose()
        DBCon.Close()

        MsgBox("更新完成..." & vbLf & "Update Done..", MsgBoxStyle.Information, "DB_File_Update")

        ' Access_Update.CompactDbFile() ' 壓縮Access資料庫

    End Sub


    Private Sub Home_Screen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If User_Unit = "LB_ZK" Then

            DutBoardDToolStripMenuItem.Enabled = True
        Else
            DutBoardDToolStripMenuItem.Enabled = False

        End If

    End Sub
End Class
