﻿Imports Microsoft.Office.Interop.Excel

Public Class EXCEL_Print

    Public xlApp As Application = New Application
    Public xsheet As Worksheet = New Worksheet


    ' Create new Application.
    
   

End Class
