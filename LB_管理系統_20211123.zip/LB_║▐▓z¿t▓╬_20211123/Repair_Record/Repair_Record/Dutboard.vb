﻿Imports System.Data.OleDb


Public Class Dutboard
    Dim No_Temp As String
    Dim P_Count As Integer

    Private Sub Dutboard_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        OpenForm = False
    End Sub

    Private Sub Dutboard_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        MaximizeBox = False
        MinimizeBox = False
        'Combox_DB()
        DB_Load()
        Button1.Enabled = False

    End Sub

    Private Sub DB_Load()

        Dim DBCon As OleDbConnection

        DBCon = New OleDbConnection(Dut_Board)

        Dim Str As String = "Select * From AoD_Card_Initial ORDER BY Family DESC, Parts_ID" '派工 資料查詢表

        Dim cmd As OleDbCommand = New OleDbCommand(Str, DBCon)
        DBCon.Open()

        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        'DBDA = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        'DBDT = New DataTable
        LB_Temp.Fill(DBST, "AoD_Temp")
        DBST.Tables("AoD_Temp").Columns.Remove("ID")
        DGView1.DataSource = DBST.Tables("AoD_Temp").DefaultView
        'DGView1.Columns("IQC_Date").HeaderText = "Date"
        DGView1.Columns("IQC_Date").DefaultCellStyle.Format = "yyyy/MM/dd"
        DBCon.Close()


    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim Str As String
        Dim DBCon As OleDbConnection = New OleDbConnection(Dut_Board)
        Dim DBCmd As OleDbCommand

        Parts_Count()

        If Trim(TextBox1.Text) = "" Or Trim(TextBox2.Text) = "" Or Trim(TextBox3.Text) = "" Or Trim(TextBox4.Text) = "" Or Trim(TextBox5.Text) = "" Or Trim(TextBox6.Text) = "" Or Trim(TextBox6.Text) = "" Then

            MsgBox("欄位有未填寫!!", MsgBoxStyle.Critical, "空值")
        ElseIf P_Count = Trim(TextBox4.Text) Then
            MsgBox("此Parts_ID 已有 " & Trim(TextBox4.Text) & " 筆AoD Board 資料, 無法建立!!", MsgBoxStyle.Critical, "Max Vaule")

        Else

            Try

                Str = "Insert Into AoD_Card_to_Parts(AoD_No, Parts_ID, Change_Date)Values('" & Trim(TextBox6.Text) & "', '" & Trim(TextBox1.Text) & "','" & Now & "')"
                DBCon.Open()
                DBCmd = New OleDbCommand(Str, DBCon)
                DBCmd.ExecuteNonQuery()
                DBCon.Close()

                Str = "Insert Into AoD_Card_Initial(IQC_Date, Parts_ID, Ttester_model, Family, Test_Mode, AoD_Install, IQC_AoD_No, Last_AoD_No )Values" & _
                                                   "( '" & Now & "' , '" & Trim(TextBox1.Text) & "', '" & Trim(ComboBox1.Text) & "', '" & Trim(TextBox2.Text) & "', '" & Trim(TextBox3.Text) & "', '" & Trim(TextBox4.Text) & "', " & _
                                                   "'" & Trim(TextBox5.Text) & "', '" & Trim(TextBox6.Text) & "')"
                DBCon.Open()
                DBCmd = New OleDbCommand(Str, DBCon)
                DBCmd.ExecuteNonQuery()
                DBCon.Close()
                DBCmd.Dispose()
                MsgBox("Add建檔完成~", MsgBoxStyle.Information, "Information")
                DB_Load()
                txtBox_Clean()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
                'MsgBox("重複Parts_ID", MsgBoxStyle.Exclamation, "重複性編號")
            Finally

                
            End Try

        End If

    End Sub


    Private Sub txtBox_Clean()

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        ComboBox1.ResetText()
        ComboBox1.Enabled = True
        TextBox1.ReadOnly = False
        TextBox2.ReadOnly = False
        TextBox3.ReadOnly = False
        TextBox4.ReadOnly = False
        TextBox5.ReadOnly = False
        TextBox5.BackColor = Color.White
        TextBox5.ForeColor = Color.Black
        Button1.Enabled = False

    End Sub

    Private Sub DGView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGView1.CellClick

        Dim row As DataGridViewRow = DGView1.CurrentRow
        '寫入變數
        TextBox1.Text = row.Cells(1).Value.ToString()
        ComboBox1.Text = row.Cells(2).Value.ToString()
        TextBox2.Text = row.Cells(3).Value.ToString()
        TextBox3.Text = row.Cells(4).Value.ToString()
        TextBox4.Text = row.Cells(5).Value.ToString()
        TextBox5.Text = row.Cells(6).Value.ToString()
        TextBox6.Text = row.Cells(7).Value.ToString()

        TextBox1.ReadOnly = True
        TextBox2.ReadOnly = True
        TextBox3.ReadOnly = True
        TextBox4.ReadOnly = True
        TextBox5.ReadOnly = True
        TextBox5.BackColor = Color.YellowGreen
        TextBox5.ForeColor = Color.White
        ComboBox1.Enabled = False
        Button1.Enabled = True

        No_Temp = row.Cells(7).Value.ToString()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        txtBox_Clean()
        TextBox5.ReadOnly = False
        TextBox5.BackColor = Color.White
        TextBox5.ForeColor = Color.Black

        Button1.Enabled = False

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Str As String
        Dim DBCon As OleDbConnection = New OleDbConnection(Dut_Board)
        Dim DBCmd As OleDbCommand

        Try

            Str = "UPDATE AoD_Card_to_Parts SET AoD_No = '" & TextBox6.Text & "' Where AoD_No = '" & No_Temp & "'"
            DBCon.Open()
            DBCmd = New OleDbCommand(Str, DBCon)
            DBCmd.ExecuteNonQuery()
            DBCon.Close()
            DBCmd.Dispose()

            MsgBox("Update更新完成~", MsgBoxStyle.Information, "Information")
            DB_Load()
            txtBox_Clean()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            'MsgBox("重複Parts_ID", MsgBoxStyle.Exclamation, "重複性編號")
        Finally
        End Try


    End Sub

    Private Sub Combox_DB()
        Dim Str As String
        Dim DBCon As OleDbConnection = New OleDbConnection(Dut_Board)
        Dim DBCmd As OleDbCommand
        Dim reader As OleDbDataReader

        Str = "Select DISTINCT Ttester_model from Tester_Type order by Ttester_model ASC"
        DBCmd = New OleDbCommand(Str, DBCon)
        DBCon.Open()
        reader = DBCmd.ExecuteReader

        While reader.Read()
            ComboBox1.Items.Add(reader.Item("Ttester_model").ToString)
        End While
        DBCon.Close()

    End Sub


    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim Str As String

        Str = "Select * From AoD_Card_Initial Order BY Parts_ID "

        If Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox6.Text)) > 0 Then
            Str = "Select * From AoD_Card_Initial Where Last_AoD_No Like '" & TextBox6.Text & "' and Parts_ID Like '" & TextBox1.Text & "'"
        ElseIf Len(Trim(TextBox1.Text)) = 0 And Len(Trim(TextBox6.Text)) > 0 Then
            Str = "Select * From AoD_Card_Initial Where Last_AoD_No Like '" & TextBox6.Text & "'"
        ElseIf Len(Trim(TextBox1.Text)) > 0 And Len(Trim(TextBox6.Text)) = 0 Then
            Str = "Select * From AoD_Card_Initial Where Parts_ID Like '" & TextBox1.Text & "'"
        End If

        Dim DBCon As OleDbConnection

        DBCon = New OleDbConnection(Dut_Board)
        Dim cmd As OleDbCommand = New OleDbCommand(Str, DBCon)
        DBCon.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        LB_Temp.Fill(DBST, "AoD_Temp")
        DBST.Tables("AoD_Temp").Columns.Remove("ID")
        DGView1.DataSource = DBST.Tables("AoD_Temp").DefaultView
        DGView1.Columns("IQC_Date").DefaultCellStyle.Format = "yyyy/MM/dd"
        DBCon.Close()

    End Sub

 
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TextBox2.Clear()
        TextBox3.Clear()

        Dim DBCon As OleDbConnection
        DBCon = New OleDbConnection(Dut_Board)
        Dim Str As String = "Select * From Parts_inquire WHERE Parts_ID Like '" & TextBox1.Text & "'" '資料查詢表
        Dim cmd As OleDbCommand = New OleDbCommand(Str, DBCon)
        DBCon.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        'DBDA = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        'DBDT = New DataTable
        LB_Temp.Fill(DBST, "Parts")
        DBCon.Close()

        Try
            Tester_Mode()
            TextBox2.Text = (DBST.Tables("Parts").Rows(0).Item(1).ToString())

            If DBST.Tables("Parts").Rows(0).Item(2).ToString() = "SINGLE" Then
                TextBox3.Text = 1
            ElseIf DBST.Tables("Parts").Rows(0).Item(2).ToString() = "DUAL" Then
                TextBox3.Text = 2
            ElseIf DBST.Tables("Parts").Rows(0).Item(2).ToString() = "TRIPLE" Then
                TextBox3.Text = 3
            ElseIf DBST.Tables("Parts").Rows(0).Item(2).ToString() = "QUAD" Then
                TextBox3.Text = 4
            ElseIf DBST.Tables("Parts").Rows(0).Item(2).ToString() = "OCTAL" Then
                TextBox3.Text = 8
            Else
                TextBox3.Text = (DBST.Tables("Parts").Rows(0).Item(2).ToString())
            End If


        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            MessageBox.Show("沒有此 『" & TextBox1.Text & "』 號碼")
            'MsgBox("重複Parts_ID", MsgBoxStyle.Exclamation, "重複性編號")
        Finally

        End Try

    End Sub

    Private Sub Tester_Mode()

        If Mid(TextBox1.Text, 7, 2) = "H9" Then
            ComboBox1.Text = "HP93000"
        ElseIf Mid(TextBox1.Text, 7, 2) = "UF" Then
            ComboBox1.Text = "UltraFlex"
        ElseIf Mid(TextBox1.Text, 7, 2) = "UP" Then
            ComboBox1.Text = "UltraFlex_Plus"
        ElseIf Mid(TextBox1.Text, 7, 2) = "IF" Then
            ComboBox1.Text = "iFlex"
        ElseIf Mid(TextBox1.Text, 7, 2) = "J7" Then
            ComboBox1.Text = "J750"
        End If

    End Sub

    Private Sub Parts_Count()

        Dim DBCon As OleDbConnection
        DBCon = New OleDbConnection(Dut_Board)
        Dim Str As String = "Select Count(Parts_ID) From AoD_Card_Initial WHERE Parts_ID Like '" & TextBox1.Text & "'" '資料查詢表
        Dim cmd As OleDbCommand = New OleDbCommand(Str, DBCon)
        DBCon.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        'DBDA = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        'DBDT = New DataTable
        LB_Temp.Fill(DBST, "Count")
        DBCon.Close()

        P_Count = (DBST.Tables("Count").Rows(0).Item(0).ToString)

    End Sub

End Class