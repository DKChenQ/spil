﻿Imports System.Data.OleDb

Public Class REMARK_LB

    Private Sub HS_LoadBoard_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If OpenForm = True Then OpenForm = False : Exit Sub

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim conn As OleDbConnection = New OleDbConnection(LB_RMK_DTAT)

        If Trim(TextBox1.Text) = "" Then '空白欄位檢查跳至"ERR01"
            conn.Close()
            MessageBox.Show("請輸入Parts_ID", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        Else

            Dim Str As String = "Insert Into LB_REMARK (Parts_ID, REMARK, ETL_DATE)Values" & _
                                                      "( '" & Trim(UCase(TextBox1.Text)) & "','" & TextBox2.Text & "', NOW )"
            conn.Open()
            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
            cmd.ExecuteNonQuery()
            conn.Close()

            MessageBox.Show("建檔完成(Add done)", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            TXT_Clean()

        End If

        conn.Dispose()

        Exit Sub

    End Sub

    Private Sub TXT_Clean()

        TextBox1.Clear()
        TextBox2.Clear()

    End Sub

End Class