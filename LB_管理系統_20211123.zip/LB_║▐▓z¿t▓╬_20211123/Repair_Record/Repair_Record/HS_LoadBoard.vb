﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports ADODB

Public Class HS_LoadBoard
    Dim conn As OleDbConnection
    Dim Str As String
    Dim Chk As New DataGridViewCheckBoxColumn
    Dim Verify As String = "Y" '接工 指標 'UPDATE

    Private Sub HS_LoadBoard_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        If User_Unit = "LB_ADMIN" Then

            Label9.Visible = True
            ComboBox1.Visible = True

            ComboBox1.Items.Add("EL")
            ComboBox1.Items.Add("HS")
            ComboBox1.Items.Add("ZK")

            ComboBox1.SelectedIndex = 1
            H_Z_Menu = ComboBox1.Text

            'H_Z_Menu = Trim(UCase(InputBox("請輸入HS 或 ZK 或 EL:", "請輸入廠區:")))

            If H_Z_Menu = "HS" Then
                H_Z_DBCon = HS_LB_Database
            ElseIf H_Z_Menu = "ZK" Then
                H_Z_DBCon = ZK_LB_Database
            ElseIf H_Z_Menu = "EL" Then
                H_Z_DBCon = EL_LB_Database
            ElseIf H_Z_Menu = "TEST" Then
                H_Z_DBCon = TEST_LB_Database
            End If

        Else
            Label9.Visible = False
            ComboBox1.Visible = False

        End If

        Lab_SendMan.Text = "" 'Send_Man:
        Lab_TesterID.Text = "" 'Tester:
        Lab_FailSite.Text = "" 'Fail Site:
        Lab_FailItem.Text = "" 'Fail Item:
        Lab_PartsID.Text = "" 'Parts_ID:
        Lab_Family.Text = "" 'Family:
        Lab_FailBin.Text = "" 'Fail Bin:
        Lab_FailReason.Text = ""
        Load_HW_Table_List()

    End Sub

    Private Sub HS_LoadBoard_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If OpenForm = True Then OpenForm = False : Exit Sub
        conn.Dispose()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '查詢
        Inquire.Show()
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow

        '寫入變數
        RV_ID = CLng(row.Cells(0).Value.ToString())
        RV_DATETIME = row.Cells(1).Value.ToString()
        RV_PARTS_ID = row.Cells(2).Value.ToString()
        RV_TESTER_ID = row.Cells(3).Value.ToString()
        RV_VENDOR = row.Cells(4).Value.ToString()
        RV_CUSTOMER = row.Cells(5).Value.ToString()
        RV_FAMILY = row.Cells(6).Value.ToString()
        'RV_Device = row.Cells(7).Value.ToString()
        'RV_PGM = row.Cells(8).Value.ToString()
        RV_TESTMODE = row.Cells(7).Value.ToString()
        RV_STATUS = row.Cells(8).Value.ToString()
        RV_FailSite = row.Cells(9).Value.ToString()
        RV_FailBin = row.Cells(10).Value.ToString()
        RV_FailItem = row.Cells(11).Value.ToString()
        RV_FailReason = row.Cells(12).Value.ToString()
        RV_STAGE = row.Cells(13).Value.ToString()
        RV_Verify = row.Cells(14).Value.ToString()
        'RV_DownTime = row.Cells(17).Value.ToString()
        RV_Send_Man = row.Cells(15).Value.ToString()
        'RV_B_Count = row.Cells(19).Value.ToString()

        Lab_SendMan.Text = RV_Send_Man 'Send_Man
        Lab_TesterID.Text = RV_TESTER_ID 'Tester_ID
        Lab_FailSite.Text = RV_FailSite 'Fail Site
        Lab_FailItem.Text = RV_FailItem  'Fail Item
        Lab_PartsID.Text = RV_PARTS_ID 'Parts_ID
        Lab_Family.Text = RV_FAMILY 'Family
        Lab_FailBin.Text = RV_FailBin 'Fail Bin
        Lab_FailReason.Text = RV_FailReason

        extend_save.Lab_SeddMan.Text = RV_Send_Man 'Send_Man
        extend_save.Lab_TesterID.Text = RV_TESTER_ID 'Tester_ID
        extend_save.Lab_FailSite.Text = RV_FailSite 'Fail Site
        extend_save.Lab_FailItem.Text = RV_FailItem 'Fail Item
        extend_save.Lab_PartsID.Text = RV_PARTS_ID 'Parts_ID
        extend_save.Lab_Family.Text = RV_FAMILY 'Family
        extend_save.Lab_FailBin.Text = RV_FailBin 'Fail Bin
        extend_save.Lab_Station.Text = RV_STAGE 'Stage 
        extend_save.Lab_TestMode.Text = RV_TESTMODE 'Test Mode
        extend_save.Lab_FailReason.Text = RV_FailReason

        If RV_Verify = "Y" Then
            Button2.Enabled = False '接單
            Button5.Enabled = True '續接
        Else
            Button2.Enabled = True '接單
            Button5.Enabled = False '續接
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '接工
        Dim cmd As OleDbCommand
        conn = New OleDbConnection(H_Z_DBCon)
        If Lab_PartsID.Text = "" Then
            MessageBox.Show("請選擇Parts", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Close_Table = "0"
            Input_Table()

            If RV_Verify = "N" Then '未維修過資料 >>寫入資料表

                Dim Str As String = "Insert Into" & Repair_Fill_List_Table & "(ID, Repair_Man, Finish_Close, ID_N, ID_Close)Values" & _
                                                                            "( '" & RV_ID & "' , '" & User_ID & "' , 'N', '1', 'N')" '接工寫入資料表 
                conn.Open()
                cmd = New OleDbCommand(Str, conn)
                cmd.ExecuteNonQuery()
                conn.Close()

                Str = " Update" & Fill_Data & "set Verify = '" & Verify & "' where ID = " & RV_ID & "" '更新派工資料表
                conn.Open()
                cmd = New OleDbCommand(Str, conn)
                cmd.ExecuteNonQuery()
                conn.Close()

                MessageBox.Show(Lab_PartsID.Text & "接工..", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Lev()
                extend_save.Show()
                DataGridView1.Enabled = False


            ElseIf RV_Verify = "Y" Then '維修過資料 >> 查詢資料表

                Dim Str As String = "Select * from" & Repair_Fill_List_Table & "where ID Like " & RV_ID & " AND ID_Close Like 'N'"
                Dim da As New OleDbDataAdapter(Str, conn)
                conn.Open()
                Dim myRes As New DataTable
                da.Fill(myRes)

                extend_save.R_Satrt_Time.Value = CDate(myRes.Rows(0)(2).ToString)
                extend_save.R_End_Time.Value = CDate(myRes.Rows(0)(3).ToString)
                extend_save.txt_LastRepairID.Text = myRes.Rows(0)(4).ToString
                extend_save.txt_FailName.Text = myRes.Rows(0)(5).ToString
                extend_save.txt_Action.Text = myRes.Rows(0)(6).ToString
                extend_save.txt_RootCause.Text = myRes.Rows(0)(7).ToString
                'extend_save.txt_ChangeParts.Text = myRes.Rows(0)(8).ToString
                extend_save.Cob_Attribute.Text = myRes.Rows(0)(9).ToString
                extend_save.Cob_FinalResult.Text = myRes.Rows(0)(10).ToString
                extend_save.Cob_NowStatus.Text = myRes.Rows(0)(11).ToString

                RFL_ID_N = CDbl(myRes.Rows(0)(14).ToString)
                conn.Close()
                Lev()
                extend_save.Show()
                DataGridView1.Enabled = False '2023/4/26

                Load_HW_Table_List()

            End If
        End If

    End Sub

    Public Sub Load_HW_Table_List() '讀取HW維修派工清單

        conn = New OleDbConnection(H_Z_DBCon)
        Dim Str As String = LB_Repair_V & "where ([Verify] <> 'C')" '派工 資料查詢表
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        LB_Temp.Fill(DBST, "LB_Temp")

        'DBDT.Columns.Remove("Device") '刪除

        DBST.Tables("LB_Temp").Columns.Remove("Device") '刪除
        DBST.Tables("LB_Temp").Columns.Remove("PGM")
        DBST.Tables("LB_Temp").Columns.Remove("DownTime")
        DBST.Tables("LB_Temp").Columns.Remove("B_Count")
        DBST.Tables("LB_Temp").Columns("Fail_Reason").SetOrdinal(12)
        DataGridView1.DataSource = DBST.Tables("LB_Temp").DefaultView
        'DataGridView1.DataSource = DBDT
        'DataGridView1.Columns("ID").Visible = True '0
        DataGridView1.Columns("Date_Time").HeaderText = "Send Date"
        DataGridView1.Columns("LB_VENDOR").HeaderText = "Vendor"
        DataGridView1.Columns("Customer").HeaderText = "Customer"
        DataGridView1.Columns("Family").HeaderText = "Family"
        DataGridView1.Columns("TEST_MODE").HeaderText = "TestMode"
        'DataGridView1.Columns("Fail_Item").HeaderText = "Fail_Item"
        DataGridView1.Columns("Stage").HeaderText = "站別"
        DataGridView1.Columns("Verify").HeaderText = "接工(Y/N)"
        ' DataGridView1.Columns("DownTime").Width = 130

        conn.Close()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click '續修接工
        Dim cmd As OleDbCommand

        If Lab_PartsID.Text = "" Then
            MessageBox.Show("請選擇Parts", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else

            If RV_Verify = "N" Then
                MessageBox.Show("此 [" & RV_PARTS_ID & "] 尚未接工，不得續修接工。" & vbCrLf & " 請按接工!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf RV_Verify = "Y" Then

                Close_Table = "2"

                Input_Table()
                Dim Str As String = "Select * from" & Repair_Fill_List_Table & "where ID Like " & RV_ID & " AND ID_Close Like 'N'"
                Dim da As New OleDbDataAdapter(Str, conn)
                conn.Open()
                Dim myRes As New DataTable
                da.Fill(myRes)
                If myRes.Rows.Count = 0 Then
                    MsgBox("資料LOCK!!")
                    Exit Sub
                Else

                    extend_save.txt_LastRepairID.Text = myRes.Rows(0)(4).ToString
                    extend_save.txt_FailName.Text = myRes.Rows(0)(5).ToString
                    extend_save.txt_Action.Text = myRes.Rows(0)(6).ToString
                    extend_save.txt_RootCause.Text = myRes.Rows(0)(7).ToString
                    'extend_save.txt_ChangeParts.Text = myRes.Rows(0)(8).ToString
                    extend_save.Cob_Attribute.Text = myRes.Rows(0)(9).ToString
                    extend_save.Cob_FinalResult.Text = myRes.Rows(0)(10).ToString
                    extend_save.Cob_NowStatus.Text = myRes.Rows(0)(11).ToString

                    RFL_ID_N = CDbl(myRes.Rows(0)(14).ToString) + 1

                    conn.Close()
                    myRes = Nothing
                End If
                Str = " Update" & Repair_Fill_List_Table & "set ID_Close = 'Y' where ID = " & RV_ID & " AND ID_Close = 'N'" '更新
                conn.Open()
                cmd = New OleDbCommand(Str, conn)
                cmd.ExecuteNonQuery()
             
                conn.Close()

                Str = "Insert Into" & Repair_Fill_List_Table & "(ID, Repair_Man, Finish_Close, ID_N, ID_Close  )Values( '" & RV_ID & "' , '" & User_ID & "' , 'N', '" & RFL_ID_N & "', 'N')"
                conn.Open()
                cmd = New OleDbCommand(Str, conn)
                cmd.ExecuteNonQuery()
                conn.Close()
                Lev()
                extend_save.Show()
                DataGridView1.Enabled = False '2023/4/26
                'Me.Close()

            End If

        End If

        Exit Sub

    End Sub

    Private Sub Lev() '計算

        Dim k As Single = 100.0
        Dim Str1 As String
        Dim cmd As OleDbCommand
        Dim Lev_PID, Lev_N As String
        Lev_PID = Microsoft.VisualBasic.Left(RV_PARTS_ID, 4) & "%"

        Dim Str As String = "Select Count(Parts_ID) from" & Repair_Done_List_V_Table & "where Parts_ID Like '" & Lev_PID & "' and Final_Result Like '%Pass' and Fail_Bin like '" & RV_FailBin & "'"

        cmd = New OleDbCommand(Str, conn)
        conn.Open()

        Dim reader As OleDbDataReader = cmd.ExecuteReader()
        While reader.Read()
            ' Console.WriteLine(reader(0).ToString())
            Lev_N = CInt(reader(0).ToString)

        End While
        conn.Close()
        reader.Close()
        reader = Nothing

        Str1 = "Select Attribute, ROUND (Count(Parts_ID)/ " & Lev_N & " * " & k & ",2) from Repair_Done_List_V where Parts_ID Like '" & Lev_PID & "' and Final_Result Like '%Pass' and Fail_Bin like '" & RV_FailBin & "' Group By Attribute order by Count(Parts_ID) DESC"
        cmd = New OleDbCommand(Str1, conn)
        conn.Open()
        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()
        myDA.Fill(myDataSet, "R1")
        extend_save.DataGridView1.DataSource = myDataSet.Tables("R1").DefaultView
        extend_save.DataGridView1.Columns(1).HeaderText = "百分比(%)"

        conn.Dispose()
        conn.Close()


    End Sub

    Private Sub sb_Count()
        Dim k As Single = 100.0
        Dim Lev_PID As String = Microsoft.VisualBasic.Left(RV_PARTS_ID, 4) & "%"
        Dim Str As String = "SELECT Attribute, ROUND(Count(Parts_ID) / T.Total * " & k & ",2) AS Percentage FROM Repair_Done_List_V, (SELECT Count(Parts_ID) AS Total FROM " & Repair_Done_List_V_Table & " WHERE Parts_ID LIKE '" & Lev_PID & "' AND Final_Result LIKE '%Pass' AND Fail_Bin LIKE '" & RV_FailBin & "') AS T WHERE Parts_ID LIKE '" & Lev_PID & "' AND Final_Result LIKE '%Pass' AND Fail_Bin LIKE '" & RV_FailBin & "' GROUP BY Attribute ORDER BY Count(Parts_ID) DESC;"
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        Using conn
            conn.Open()
            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "R1")
            extend_save.DataGridView1.DataSource = myDataSet.Tables("R1").DefaultView
            extend_save.DataGridView1.Columns(1).HeaderText = "百分比(%)"
        End Using
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click '資料更新
        Lab_SendMan.Text = "" '清除資料
        Lab_TesterID.Text = "" '清除資料
        Lab_FailSite.Text = "" '清除資料
        Lab_FailItem.Text = "" '清除資料
        Lab_PartsID.Text = "" '清除資料
        Lab_Family.Text = "" '清除資料
        Lab_FailBin.Text = "" '清除資料
        Lab_FailReason.Text = ""
        Load_HW_Table_List()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click ' 報表
        'EXCEL_OUT()
        e_out1()

        'New_Excel_Out()

        'Report_out()

    End Sub

    Private Sub Input_Table()

        Dim i As Integer = 0
        Dim conn As New OleDbConnection(ComList_Database)

        'Get Attribute items
        Dim attributeStr As String = "SELECT item, change_parts FROM Attribute ORDER BY Item ASC"
        Dim attributeCmd As New OleDbCommand(attributeStr, conn)
        conn.Open()
        Dim attributeReader As OleDbDataReader = attributeCmd.ExecuteReader()
        While attributeReader.Read()
            extend_save.Cob_Attribute.Items.Add(attributeReader("item").ToString())
            Arr_Attribute(i) = attributeReader("change_parts").ToString() '2021/8/9 NEW ADD
            i += 1
        End While
        attributeReader.Close()

        'Get Man items
        Dim manStr As String = "SELECT item FROM Text_List WHERE Item_Name LIKE 'Man' and Site Like '" & User_Unit & "' ORDER BY item ASC"
        Dim manCmd As New OleDbCommand(manStr, conn)
        Dim manReader As OleDbDataReader = manCmd.ExecuteReader()
        While manReader.Read()
            extend_save.txt_RepairManID.Items.Add(manReader("item").ToString())
        End While
        manReader.Close()

        'Get Now_Status items
        Dim statusStr As String = "SELECT item FROM Text_List WHERE Item_Name LIKE 'Now_Status'"
        Dim statusCmd As New OleDbCommand(statusStr, conn)
        Dim statusReader As OleDbDataReader = statusCmd.ExecuteReader()
        While statusReader.Read()
            extend_save.Cob_NowStatus.Items.Add(statusReader("item").ToString())
        End While
        statusReader.Close()

        conn.Close()


        extend_save.Cob_FinalResult.Items.Add("Online Pass")
        extend_save.Cob_FinalResult.Items.Add("Online Fail")
        extend_save.Cob_FinalResult.Items.Add("Offline Pass")
        extend_save.Cob_FinalResult.Items.Add("Offline Fail")
        ' extend_save.Cob_FinalResult.Items.Add("Offline Verify Pass")

    End Sub

    Private Sub EXCEL_OUT() '報表 未使用

        Dim k, g, m, i As Integer
        Dim Status_Name As String
        Dim xlApp As Excel.Application = New Excel.ApplicationClass
        Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
        ' Dim excelBook As Microsoft.Office.Interop.Excel._Workbook = Excel.Workbooks.Add(Type.Missing)
        Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
        xlApp.Visible = False
        k = 0
        m = 1
        Try

            For n = 1 To 10

                If n = 1 Then
                    Status_Name = "Online fail L/B"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Online Fail' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site, Repair_Date_ST"
                ElseIf n = 2 Then
                    Status_Name = "Offline fail L/B 待維修"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 3 Then
                    Status_Name = "Offline fail L/B 待驗證"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待驗證' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 4 Then
                    Status_Name = "Offline fail 待維修/驗證(工程)"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修/驗證(工程)' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 5 Then
                    Status_Name = "Offline fail L/B 待料件"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待料件' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 6 Then
                    Status_Name = "Offline fail L/B 待PD支援"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待PD支援' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 7 Then
                    Status_Name = "Offline fail L/B 待Vendor"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待Vendor' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 8 Then
                    Status_Name = "Offline fail L/B 待追蹤"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 9 Then
                    Status_Name = "Offline fail L/B 待委外"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 10 Then
                    Status_Name = "Offline fail L/B 已委外"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '已委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    '  ElseIf n = 11 Then
                    '      Status_Name = "Offline Verify Pass L/B 待追蹤"
                    '      Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Verify Pass' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                End If

                conn = New OleDbConnection(H_Z_DBCon)
                Dim da As New OleDbDataAdapter(Str, conn)

                conn.Open()
                Dim myRes As New DataSet
                da.Fill(myRes)

                excelWorksheet.Range("A" & m).Interior.Color = RGB(255, 255, 128)
                excelWorksheet.Range("A" & m).Font.Bold = True
                excelWorksheet.Range("A" & m).Font.Color = RGB(0, 0, 0)

                excelWorksheet.Range("A" & m).Value = Status_Name
                excelWorksheet.Range("A" & m & ":B" & m + 1).Merge()
                excelWorksheet.Range("C" & m).Value = "Q'ty"

                excelWorksheet.Range("D1").Value = "總數量"
                excelWorksheet.Range("A" & m & ":C" & m).Font.Bold = True
                excelWorksheet.Range("A" & m & ":C" & m).Font.Color = RGB(0, 0, 0)
                excelWorksheet.Range("A" & m & ":C" & m + 1).Borders.LineStyle = 1

                m = m + 2

                excelWorksheet.Range("A" & m & ":Y" & m).Interior.Color = RGB(0, 128, 0)
                excelWorksheet.Range("A" & m & ":Y" & m).Font.Bold = True
                excelWorksheet.Range("A" & m & ":Y" & m).Font.Color = RGB(255, 255, 255)
                excelWorksheet.Range("A" & m & ":Y" & m).Borders.LineStyle = 1



                For g = 0 To myRes.Tables(0).Columns.Count - 1

                    excelWorksheet.Cells(m, g + 1) = myRes.Tables(0).Columns.Item(g).ColumnName '欄名

                Next

                For i = 0 To myRes.Tables(0).Rows.Count - 1 '筆數

                    For j = 0 To myRes.Tables(0).Columns.Count - 1 '欄數

                        excelWorksheet.Cells(m + 1, j + 1) = myRes.Tables(0).Rows(i).Item(j) '資料

                    Next

                    m = m + 1
                Next


                excelWorksheet.Range("C" & m - (i + 1)).Value = i

                conn.Close()
                myRes = Nothing

                k = k + i '總數
                m = m + 2

            Next n

            excelWorksheet.Range("D2").Value = k ' 總數

            excelWorksheet.Range("D1").Font.Bold = True
            excelWorksheet.Range("D1").Font.Color = RGB(0, 0, 0)
            excelWorksheet.Range("D1:D2").Borders.LineStyle = 1

            excelWorksheet.Name = "未完成維修List"
            ' xlApp.ActiveWorkbook.SaveAs("D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "未完成維修List.xlsx")

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                excelBook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

            xlApp.DisplayAlerts = True
            xlApp.Visible = False
            xlApp.Quit()
            xlApp = Nothing
            GC.Collect()

        End Try

    End Sub

    Private Sub e_out()

        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset
        Dim excelApp As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
        Dim excelBook As Excel.Workbook = excelApp.Workbooks.Add
        'Dim excelApp As Excel.Application = New Excel.Application
        Dim NewWorksheet As Excel.Worksheet
        Dim j As Integer = 1
        Dim k_Total As Integer = 0
        Dim S_Total As Integer = 0
        Dim Now_Total As Integer = 0
        Dim Status_Name As String

        excelApp.DisplayAlerts = False ''停用警告訊息
        excelApp.Visible = False '設置EXCEL對象可見

        'excelApp.Workbooks.Add()
        NewWorksheet = excelApp.Application.Sheets(1)

        Try

            For n = 1 To 11

                If n = 1 Then
                    Status_Name = "Online fail L/B"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Online Fail' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site, Repair_Date_ST"
                ElseIf n = 2 Then
                    Status_Name = "Offline fail L/B 待維修"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 3 Then
                    Status_Name = "Offline fail L/B 待驗證"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待驗證' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 4 Then
                    Status_Name = "Offline fail 待維修/驗證(工程)"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修/驗證(工程)' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 5 Then
                    Status_Name = "Offline fail L/B 待料件"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待料件' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 6 Then
                    Status_Name = "Offline fail L/B 待PD支援"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待PD支援' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 7 Then
                    Status_Name = "Offline fail L/B 待Vendor"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待Vendor' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 8 Then
                    Status_Name = "Offline fail L/B 待追蹤"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 9 Then
                    Status_Name = "Offline fail L/B 待委外"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                ElseIf n = 10 Then
                    Status_Name = "Offline fail L/B 已委外"
                    Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '已委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    '  ElseIf n = 11 Then
                    '      Status_Name = "Offline Verify Pass L/B 待追蹤"
                    '      Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Verify Pass' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                End If

                'j = 1

                NewWorksheet.Range("A" & j).Interior.Color = RGB(255, 255, 128)
                NewWorksheet.Range("A" & j).Font.Bold = True
                NewWorksheet.Range("A" & j).Font.Color = RGB(0, 0, 0)

                NewWorksheet.Range("A" & j).Value = Status_Name
                NewWorksheet.Range("A" & j & ":B" & j + 1).Merge()
                NewWorksheet.Range("C" & j).Value = "Q'ty"

                NewWorksheet.Range("D1").Value = "總數量"
                NewWorksheet.Range("A" & j & ":C" & j).Font.Bold = True
                NewWorksheet.Range("A" & j & ":C" & j).Font.Color = RGB(0, 0, 0)
                NewWorksheet.Range("A" & j & ":C" & j + 1).Borders.LineStyle = 1

                j = j + 2 ' j=3

                NewWorksheet.Range("A" & j & ":Y" & j).Interior.Color = RGB(0, 128, 0)
                NewWorksheet.Range("A" & j & ":Y" & j).Font.Bold = True
                NewWorksheet.Range("A" & j & ":Y" & j).Font.Color = RGB(255, 255, 255)
                NewWorksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1
                NewWorksheet.Range("A" & j).Value = "Down_Date"
                NewWorksheet.Range("B" & j).Value = "Repair_Date_ST"
                NewWorksheet.Range("C" & j).Value = "Repair_Date_END"
                NewWorksheet.Range("D" & j).Value = "Parts_ID"
                NewWorksheet.Range("E" & j).Value = "Tester_ID"
                NewWorksheet.Range("F" & j).Value = "Customer"
                NewWorksheet.Range("G" & j).Value = "Family"
                NewWorksheet.Range("H" & j).Value = "Device"
                NewWorksheet.Range("I" & j).Value = "Vendor"
                NewWorksheet.Range("J" & j).Value = "Test_Mode"
                NewWorksheet.Range("K" & j).Value = "Stage"
                NewWorksheet.Range("L" & j).Value = "Fail_Site"
                NewWorksheet.Range("M" & j).Value = "Fail_Bin"
                NewWorksheet.Range("N" & j).Value = "Fail_Item"
                NewWorksheet.Range("O" & j).Value = "Send_Man"
                NewWorksheet.Range("P" & j).Value = "Fail_Name"
                NewWorksheet.Range("Q" & j).Value = "Action"
                NewWorksheet.Range("R" & j).Value = "Root_Cause"
                NewWorksheet.Range("S" & j).Value = "Change_Parts"
                NewWorksheet.Range("T" & j).Value = "Attribute"
                NewWorksheet.Range("U" & j).Value = "Final_Result"
                NewWorksheet.Range("V" & j).Value = "Now_Status"
                NewWorksheet.Range("W" & j).Value = "Total_Time"
                NewWorksheet.Range("X" & j).Value = "Repair_Man"
                NewWorksheet.Range("Y" & j).Value = "Stay of days"

                j = j + 1 ' j = 4  放資料 4 等於 第一筆資料

                myCon = New Connection
                myCon.Open(H_Z_DBCon)

                myRst = New Recordset
                myRst = myCon.Execute(Str)

                Do While Not myRst.EOF

                    NewWorksheet.Cells(j, 1) = Microsoft.VisualBasic.Format(myRst.Fields("Date_Time").Value, "yyyy/MM/dd")
                    NewWorksheet.Cells(j, 2) = myRst.Fields("Repair_Date_ST").Value
                    NewWorksheet.Cells(j, 3) = myRst.Fields("Repair_Date_END").Value
                    NewWorksheet.Cells(j, 4) = myRst.Fields("Parts_ID").Value
                    NewWorksheet.Cells(j, 5) = myRst.Fields("Tester_ID").Value
                    NewWorksheet.Cells(j, 6) = myRst.Fields("Customer").Value
                    NewWorksheet.Cells(j, 7) = myRst.Fields("Family").Value
                    NewWorksheet.Cells(j, 8) = myRst.Fields("Device").Value
                    NewWorksheet.Cells(j, 9) = myRst.Fields("LB_Vendor").Value
                    NewWorksheet.Cells(j, 10) = myRst.Fields("Test_Mode").Value
                    NewWorksheet.Cells(j, 11) = myRst.Fields("Stage").Value
                    NewWorksheet.Cells(j, 12) = myRst.Fields("Fail_Site").Value
                    NewWorksheet.Cells(j, 13) = myRst.Fields("Fail_Bin").Value
                    NewWorksheet.Cells(j, 14) = myRst.Fields("Fail_Item").Value
                    NewWorksheet.Cells(j, 15) = myRst.Fields("Send_Man").Value
                    NewWorksheet.Cells(j, 16) = myRst.Fields("Fail_Name").Value
                    NewWorksheet.Cells(j, 17) = myRst.Fields("Action_R").Value
                    NewWorksheet.Cells(j, 18) = myRst.Fields("Root_Cause").Value
                    NewWorksheet.Cells(j, 19) = myRst.Fields("Change_Parts").Value
                    NewWorksheet.Cells(j, 20) = myRst.Fields("Attribute").Value
                    NewWorksheet.Cells(j, 21) = myRst.Fields("Final_Result").Value
                    NewWorksheet.Cells(j, 22) = myRst.Fields("Now_Status").Value
                    NewWorksheet.Cells(j, 23) = myRst.Fields("Total_Time").Value
                    NewWorksheet.Cells(j, 24) = myRst.Fields("Repair_Man").Value
                    NewWorksheet.Cells(j, 25) = Microsoft.VisualBasic.DateDiff("d", myRst.Fields("Date_Time").Value, Now)

                    NewWorksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1
                    myRst.MoveNext()
                    j = j + 1

                    S_Total = S_Total + 1
                    k_Total = k_Total + 1

                Loop

                If S_Total = 0 Then

                    NewWorksheet.Range("C" & j - 2).Value = S_Total
                Else

                    NewWorksheet.Range("C" & j - (S_Total + 2)).Value = S_Total

                End If



                Now_Total = Now_Total + S_Total

                j = j + 1
                S_Total = 0
            Next n

            NewWorksheet.Range("D1").Font.Bold = True
            NewWorksheet.Range("D1").Font.Color = RGB(0, 0, 0)
            NewWorksheet.Range("D1:D2").Borders.LineStyle = 1
            NewWorksheet.Range("D2").Value = Now_Total
            'NewWorksheet.Columns("A:Y").AutoFit()
            NewWorksheet.Columns("A:P").ColumnWidth = 13
            NewWorksheet.Columns("Q").ColumnWidth = 50
            NewWorksheet.Columns("R:Y").ColumnWidth = 13
            

            NewWorksheet.Name = "未完成維修List"

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                excelBook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

            ' excelApp.ActiveWorkbook.SaveAs("D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "未完成維修List.xlsx")
            excelApp.DisplayAlerts = True
            'excelApp.Visible = False


            ' If Not myRst Is Nothing Then
            ' If myRst.State = 1 Then myRst.Close()
            ' End If
            ' If Not myCon Is Nothing Then
            ' If myCon.State = 1 Then myCon.Close()
            ' End If

            myRst.Close()
            myCon.Close()

            myRst = Nothing
            myCon = Nothing

            excelApp.Quit()

            excelApp = Nothing
            GC.Collect()

            End
            'MessageBox.Show("匯出成功，查看D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "未完成維修List.xlsx", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try

    End Sub

    Private Sub New_Excel_Out()
        Dim Done_List_Table As DataSet
        Dim rowsTotal, colsTotal As Integer
        Dim rowName, colName As String


        '============== 連結ACCESS 資料庫
        conn = New OleDbConnection(H_Z_DBCon)
        Try

            Str = "Select * from" & Repair_Done_List_V_Table & "where Finish_Close Like 'N' and ID_Close Like 'N' and not isnull(Final_Result) order by Final_Result asc ,Now_Status "
            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
            conn.Open()
            Dim EXT_Table As OleDbDataAdapter = New OleDbDataAdapter(cmd)

            Done_List_Table = New DataSet()
            EXT_Table.Fill(Done_List_Table, "D_Table")
            DataGridView2.DataSource = Done_List_Table.Tables("D_Table").DefaultView


            DataGridView2.Columns.Remove("ID")
            DataGridView2.Columns.Remove("Finish_Close")
            DataGridView2.Columns.Remove("ID_Close")
            DataGridView2.Columns.Remove("LB_VENDOR")

            DataGridView2.Columns("Date_Time").HeaderText = "Down_Date"
            DataGridView2.Columns("Action_R").HeaderText = "Action"
            ' DataGridView2.Columns("Tester_ID").HeaderText = "Tester"
            DataGridView2.Columns("Date_Time").DefaultCellStyle.Format = "yyyy/MM/dd"

            rowsTotal = DataGridView2.RowCount - 1
            colsTotal = DataGridView2.Columns.Count - 1

            Done_List_Table.Dispose()
            conn.Close()

            '============== Excel

            Dim xlApp As Excel.Application = New Excel.ApplicationClass
            Dim workbook As Excel.Workbook = xlApp.Workbooks.Add
            Dim Worksheet As Excel.Worksheet = CType(workbook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = False

            '=============變數
            Dim j As Integer = 1
            Dim i As Integer
            Dim k As Integer
            Dim Status_Name As String

            For m = 1 To 1

                If m = 1 Then
                    Status_Name = "Online fail L/B"
                    rowName = "Offline Fail"
                    colName = "待維修"

                End If

                '1
                Worksheet.Range("A" & j).Interior.Color = RGB(255, 255, 128)
                Worksheet.Range("A" & j).Font.Bold = True
                Worksheet.Range("A" & j).Font.Color = RGB(0, 0, 0)

                Worksheet.Range("A" & j).Value = Status_Name
                Worksheet.Range("A" & j & ":B" & j + 1).Merge()
                Worksheet.Range("C" & j).Value = "Q'ty"

                Worksheet.Range("D1").Value = "總數量"
                Worksheet.Range("A" & j & ":C" & j).Font.Bold = True
                Worksheet.Range("A" & j & ":C" & j).Font.Color = RGB(0, 0, 0)
                Worksheet.Range("A" & j & ":C" & j + 1).Borders.LineStyle = 1


                j = j + 2 'row 3

                Worksheet.Range("A" & j & ":Y" & j).Interior.Color = RGB(0, 128, 0)
                Worksheet.Range("A" & j & ":Y" & j).Font.Bold = True
                Worksheet.Range("A" & j & ":Y" & j).Font.Color = RGB(255, 255, 255)
                Worksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1


                For i = 0 To colsTotal
                    'Worksheet.Cells(j, i) = Done_List_Table.Tables("D_Table").Columns(i).ColumnName '資料欄名
                    Worksheet.Cells(j, i + 1) = DataGridView2.Columns(i).HeaderText

                Next

                Worksheet.Cells(j, i + 1) = "Stay of days"

                j = j + 1 ' row 4



                ' DataGridView2.Rows(k).Cells(19).Value = rowName
                ' colName = DataGridView2.Rows(k).Cells(20).Value

                For k = 0 To rowsTotal
                    For i = 0 To colsTotal


                        'Worksheet.Cells(j + k, i + 1) = Done_List_Table.Tables(0).Rows(k).Item(i) ' row,col
                        Worksheet.Cells(j + k, i + 1) = DataGridView2.Rows(k).Cells(i).Value ' row,col

                    Next
                Next

            Next

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                workbook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

            xlApp.Quit()
            xlApp = Nothing


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

            GC.Collect()

        End Try

    End Sub

    Private Sub DataGridView1_CellMouseDoubleClick(ByVal sender As Object, ByVal e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseDoubleClick
        ' 只處理滑鼠左鍵雙擊事件
        If e.Button = MouseButtons.Left And e.Clicks = 2 Then
            ' 取得目前選取的欄位
            Dim currentCol As DataGridViewColumn = DataGridView1.Columns(e.ColumnIndex)
            ' 彈跳輸入密碼的視窗
            Dim password As String = InputBox("請輸入密碼", "驗證密碼")
            ' 驗證密碼正確
            If password = "123" Then ' 將 "mypassword" 改為您要設定的密碼
                ' 設定目前選取的欄位為可修改
                'currentCol.ReadOnly = False

                Change_Data.Lab_PartsID.Text = RV_PARTS_ID 'Tester_ID
                Change_Data.Lab_Family.Text = RV_FAMILY 'Family
                Change_Data.TextBox1.Text = RV_TESTER_ID 'TESTER_ID
                Change_Data.TextBox2.Text = RV_FailSite
                Change_Data.TextBox3.Text = RV_FailBin
                Change_Data.TextBox4.Text = RV_STAGE

                ' 設定 Form1 的 TopMost 屬性為 True，讓視窗顯示在最上層, ' 顯示 Form2，這樣 Form1 就會鎖定在 Form2 的上方
                Change_Data.TopMost = True

                ' 設定 DataGridView1 的 SelectionMode 屬性為 FullRowSelect，禁用選擇功能
                DataGridView1.Enabled = False

                ' 設定 Form1 的 FormBorderStyle 屬性為 FixedDialog，禁用最大化和最小化按鈕
                Change_Data.FormBorderStyle = FormBorderStyle.FixedDialog

                Change_Data.Show()

            Else
                MessageBox.Show("密碼錯誤")
            End If
        End If
    End Sub


    Private Sub e_out1()

        Dim excelApp As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
        Dim excelBook As Excel.Workbook = excelApp.Workbooks.Add
        Dim NewWorksheet As Excel.Worksheet
        Dim j As Integer = 1
        Dim k_Total As Integer = 0
        Dim S_Total As Integer = 0
        Dim Now_Total As Integer = 0
        Dim Status_Name As String

        '... [其餘的程式碼保持不變]

        excelApp.DisplayAlerts = False ''停用警告訊息
        excelApp.Visible = False '設置EXCEL對象可見

        'excelApp.Workbooks.Add()
        NewWorksheet = excelApp.Application.Sheets(1)

        Try
            '使用OLEDB方式進行連接
            Using myCon As New OleDb.OleDbConnection(H_Z_DBCon)

                myCon.Open()

                For n = 1 To 10

                    '... [設定SQL查詢]

                    If n = 1 Then
                        Status_Name = "Online fail L/B"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Online Fail' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site, Repair_Date_ST"
                    ElseIf n = 2 Then
                        Status_Name = "Offline fail L/B 待維修"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 3 Then
                        Status_Name = "Offline fail L/B 待驗證"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待驗證' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 4 Then
                        Status_Name = "Offline fail 待維修/驗證(工程)"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待維修/驗證(工程)' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 5 Then
                        Status_Name = "Offline fail L/B 待料件"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待料件' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 6 Then
                        Status_Name = "Offline fail L/B 待PD支援"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待PD支援' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 7 Then
                        Status_Name = "Offline fail L/B 待Vendor"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待Vendor' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 8 Then
                        Status_Name = "Offline fail L/B 待追蹤"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 9 Then
                        Status_Name = "Offline fail L/B 待委外"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '待委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    ElseIf n = 10 Then
                        Status_Name = "Offline fail L/B 已委外"
                        Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Fail' and Now_Status Like '已委外' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                        '  ElseIf n = 11 Then
                        '      Status_Name = "Offline Verify Pass L/B 待追蹤"
                        '      Str = "Select * from Repair_Done_List_V where Final_Result Like 'Offline Verify Pass' and Now_Status Like '待追蹤' and Finish_Close Like 'N' and ID_Close Like 'N' order by Family Asc, Fail_site , Repair_Date_ST"
                    End If

                    'j = 1

                    NewWorksheet.Range("A" & j).Interior.Color = RGB(255, 255, 128)
                    NewWorksheet.Range("A" & j).Font.Bold = True
                    NewWorksheet.Range("A" & j).Font.Color = RGB(0, 0, 0)

                    NewWorksheet.Range("A" & j).Value = Status_Name
                    NewWorksheet.Range("A" & j & ":B" & j + 1).Merge()
                    NewWorksheet.Range("C" & j).Value = "Q'ty"

                    NewWorksheet.Range("D1").Value = "總數量"
                    NewWorksheet.Range("A" & j & ":C" & j).Font.Bold = True
                    NewWorksheet.Range("A" & j & ":C" & j).Font.Color = RGB(0, 0, 0)
                    NewWorksheet.Range("A" & j & ":C" & j + 1).Borders.LineStyle = 1

                    j = j + 2 ' j=3

                    NewWorksheet.Range("A" & j & ":Y" & j).Interior.Color = RGB(0, 128, 0)
                    NewWorksheet.Range("A" & j & ":Y" & j).Font.Bold = True
                    NewWorksheet.Range("A" & j & ":Y" & j).Font.Color = RGB(255, 255, 255)
                    NewWorksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1
                    NewWorksheet.Range("A" & j).Value = "Down_Date"
                    NewWorksheet.Range("B" & j).Value = "Repair_Date_ST"
                    NewWorksheet.Range("C" & j).Value = "Repair_Date_END"
                    NewWorksheet.Range("D" & j).Value = "Parts_ID"
                    NewWorksheet.Range("E" & j).Value = "Tester_ID"
                    NewWorksheet.Range("F" & j).Value = "Customer"
                    NewWorksheet.Range("G" & j).Value = "Family"
                    NewWorksheet.Range("H" & j).Value = "Device"
                    NewWorksheet.Range("I" & j).Value = "Vendor"
                    NewWorksheet.Range("J" & j).Value = "Test_Mode"
                    NewWorksheet.Range("K" & j).Value = "Stage"
                    NewWorksheet.Range("L" & j).Value = "Fail_Site"
                    NewWorksheet.Range("M" & j).Value = "Fail_Bin"
                    NewWorksheet.Range("N" & j).Value = "Fail_Item"
                    NewWorksheet.Range("O" & j).Value = "Send_Man"
                    NewWorksheet.Range("P" & j).Value = "Fail_Name"
                    NewWorksheet.Range("Q" & j).Value = "Action"
                    NewWorksheet.Range("R" & j).Value = "Root_Cause"
                    NewWorksheet.Range("S" & j).Value = "Change_Parts"
                    NewWorksheet.Range("T" & j).Value = "Attribute"
                    NewWorksheet.Range("U" & j).Value = "Final_Result"
                    NewWorksheet.Range("V" & j).Value = "Now_Status"
                    NewWorksheet.Range("W" & j).Value = "Total_Time"
                    NewWorksheet.Range("X" & j).Value = "Repair_Man"
                    NewWorksheet.Range("Y" & j).Value = "Stay of days"

                    j = j + 1 ' j = 4  放資料 4 等於 第一筆資料


                    '使用OleDbCommand執行SQL查詢
                    Using cmd As New OleDb.OleDbCommand(Str, myCon)
                        Using myRst As OleDb.OleDbDataReader = cmd.ExecuteReader()

                            Do While myRst.Read()

                                '使用myRst("ColumnName")讀取資料
                                NewWorksheet.Cells(j, 1) = Microsoft.VisualBasic.Format(myRst("Date_Time"), "yyyy/MM/dd")
                                NewWorksheet.Cells(j, 2) = myRst("Repair_Date_ST")
                                '... [其他列的資料]
                                NewWorksheet.Cells(j, 3) = myRst("Repair_Date_END")
                                NewWorksheet.Cells(j, 4) = myRst("Parts_ID")
                                NewWorksheet.Cells(j, 5) = myRst("Tester_ID")
                                NewWorksheet.Cells(j, 6) = myRst("Customer")
                                NewWorksheet.Cells(j, 7) = myRst("Family")
                                NewWorksheet.Cells(j, 8) = myRst("Device")
                                NewWorksheet.Cells(j, 9) = myRst("LB_Vendor")
                                NewWorksheet.Cells(j, 10) = myRst("Test_Mode")
                                NewWorksheet.Cells(j, 11) = myRst("Stage")
                                NewWorksheet.Cells(j, 12) = myRst("Fail_Site")
                                NewWorksheet.Cells(j, 13) = myRst("Fail_Bin")
                                NewWorksheet.Cells(j, 14) = myRst("Fail_Item")
                                NewWorksheet.Cells(j, 15) = myRst("Send_Man")
                                NewWorksheet.Cells(j, 16) = myRst("Fail_Name")
                                NewWorksheet.Cells(j, 17) = myRst("Action_R")
                                NewWorksheet.Cells(j, 18) = myRst("Root_Cause")
                                NewWorksheet.Cells(j, 19) = myRst("Change_Parts")
                                NewWorksheet.Cells(j, 20) = myRst("Attribute")
                                NewWorksheet.Cells(j, 21) = myRst("Final_Result")
                                NewWorksheet.Cells(j, 22) = myRst("Now_Status")
                                NewWorksheet.Cells(j, 23) = myRst("Total_Time")
                                NewWorksheet.Cells(j, 24) = myRst("Repair_Man")
                                NewWorksheet.Cells(j, 25) = Microsoft.VisualBasic.DateDiff("d", myRst("Date_Time"), Now)

                                NewWorksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1

                                j = j + 1
                                S_Total = S_Total + 1
                                k_Total = k_Total + 1
                            Loop
                        End Using
                    End Using

                    '... [其餘的程式碼保持不變]

                    If S_Total = 0 Then

                        NewWorksheet.Range("C" & j - 2).Value = S_Total
                    Else

                        NewWorksheet.Range("C" & j - (S_Total + 2)).Value = S_Total

                    End If



                    Now_Total = Now_Total + S_Total

                    j = j + 1
                    S_Total = 0
                Next n
            End Using

            '... [其餘的程式碼保持不變]
            NewWorksheet.Range("D1").Font.Bold = True
            NewWorksheet.Range("D1").Font.Color = RGB(0, 0, 0)
            NewWorksheet.Range("D1:D2").Borders.LineStyle = 1
            NewWorksheet.Range("D2").Value = Now_Total
            'NewWorksheet.Columns("A:Y").AutoFit()
            NewWorksheet.Columns("A:P").ColumnWidth = 13
            NewWorksheet.Columns("Q").ColumnWidth = 50
            NewWorksheet.Columns("R:Y").ColumnWidth = 13


            NewWorksheet.Name = "未完成維修List"

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                excelBook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            '... [其餘的程式碼保持不變]
            ' excelApp.ActiveWorkbook.SaveAs("D:\" & Format(Now, "yyyyMMddHHmm") & "_" & "未完成維修List.xlsx")
            excelApp.DisplayAlerts = True
            'excelApp.Visible = False

            ' If Not myRst Is Nothing Then
            ' If myRst.State = 1 Then myRst.Close()
            ' End If
            ' If Not myCon Is Nothing Then
            ' If myCon.State = 1 Then myCon.Close()
            ' End If

            excelApp.Quit()
            excelApp = Nothing
            GC.Collect()
        End Try
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        H_Z_Menu = ComboBox1.Text

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        ElseIf H_Z_Menu = "EL" Then
            H_Z_DBCon = EL_LB_Database
        ElseIf H_Z_Menu = "TEST" Then
            H_Z_DBCon = TEST_LB_Database
        End If


        Lab_SendMan.Text = "" 'Send_Man:
        Lab_TesterID.Text = "" 'Tester:
        Lab_FailSite.Text = "" 'Fail Site:
        Lab_FailItem.Text = "" 'Fail Item:
        Lab_PartsID.Text = "" 'Parts_ID:
        Lab_Family.Text = "" 'Family:
        Lab_FailBin.Text = "" 'Fail Bin:
        Lab_FailReason.Text = ""
        Load_HW_Table_List()

    End Sub
End Class