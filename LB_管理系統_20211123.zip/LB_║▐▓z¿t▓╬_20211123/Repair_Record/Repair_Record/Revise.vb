﻿
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports ADODB

Public Class Revise

    Dim conn As OleDbConnection
    Dim Str As String
    Dim Chk As New DataGridViewCheckBoxColumn
    Dim Verify As String = "Y" '接工 指標 'UPDATE

    Private Sub Revise_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Load_HW_Table_List()
    End Sub

    Public Sub Load_HW_Table_List() '讀取HW維修派工清單

        conn = New OleDbConnection(H_Z_DBCon)
        Dim Str As String = Revice_Table & "where ([ID_CLOSE] <> 'N')" '派工 資料查詢表
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        LB_Temp.Fill(DBST, "LB_Temp")

        'DBDT.Columns.Remove("Device") '刪除

        DBST.Tables("LB_Temp").Columns.Remove("Device") '刪除
        DBST.Tables("LB_Temp").Columns.Remove("PGM")
        'DBST.Tables("LB_Temp").Columns.Remove("DownTime")
        'DBST.Tables("LB_Temp").Columns.Remove("B_Count")
        DBST.Tables("LB_Temp").Columns("Fail_Reason").SetOrdinal(12)
        DataGridView1.DataSource = DBST.Tables("LB_Temp").DefaultView
        'DataGridView1.DataSource = DBDT
        'DataGridView1.Columns("ID").Visible = True '0
        DataGridView1.Columns("Date_Time").HeaderText = "Send Date"
        DataGridView1.Columns("LB_VENDOR").HeaderText = "Vendor"
        DataGridView1.Columns("Customer").HeaderText = "Customer"
        DataGridView1.Columns("Family").HeaderText = "Family"
        DataGridView1.Columns("TEST_MODE").HeaderText = "TestMode"
        'DataGridView1.Columns("Fail_Item").HeaderText = "Fail_Item"
        DataGridView1.Columns("Stage").HeaderText = "站別"
        'DataGridView1.Columns("Verify").HeaderText = "接工(Y/N)"
        ' DataGridView1.Columns("DownTime").Width = 130
        conn.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click




    End Sub

  
End Class