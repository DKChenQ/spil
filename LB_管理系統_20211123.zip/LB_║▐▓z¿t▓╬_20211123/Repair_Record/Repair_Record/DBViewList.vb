﻿Module DBViewList

    Public Mers_View As String = "Select * from mers " ' order by UserName ASC"
    Public Done_View As String = "Select * from DoneList "

End Module
