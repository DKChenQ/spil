﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Revise
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Revise))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Lab_FailReason = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Button6 = New System.Windows.Forms.Button
        Me.Lab_FailBin = New System.Windows.Forms.Label
        Me.Lab_Family = New System.Windows.Forms.Label
        Me.Lab_PartsID = New System.Windows.Forms.Label
        Me.Lab_FailItem = New System.Windows.Forms.Label
        Me.Lab_FailSite = New System.Windows.Forms.Label
        Me.Lab_TesterID = New System.Windows.Forms.Label
        Me.Lab_SendMan = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Lab_FailReason)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.Lab_FailBin)
        Me.GroupBox1.Controls.Add(Me.Lab_Family)
        Me.GroupBox1.Controls.Add(Me.Lab_PartsID)
        Me.GroupBox1.Controls.Add(Me.Lab_FailItem)
        Me.GroupBox1.Controls.Add(Me.Lab_FailSite)
        Me.GroupBox1.Controls.Add(Me.Lab_TesterID)
        Me.GroupBox1.Controls.Add(Me.Lab_SendMan)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1416, 213)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Lab_FailReason
        '
        Me.Lab_FailReason.AutoSize = True
        Me.Lab_FailReason.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_FailReason.Location = New System.Drawing.Point(473, 145)
        Me.Lab_FailReason.Name = "Lab_FailReason"
        Me.Lab_FailReason.Size = New System.Drawing.Size(60, 13)
        Me.Lab_FailReason.TabIndex = 47
        Me.Lab_FailReason.Text = "FailReason"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label8.Location = New System.Drawing.Point(378, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 15)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "Fail_Reason:"
        '
        'Button6
        '
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(977, 129)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(78, 40)
        Me.Button6.TabIndex = 44
        Me.Button6.Text = "畫面" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "更新"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Lab_FailBin
        '
        Me.Lab_FailBin.AutoSize = True
        Me.Lab_FailBin.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_FailBin.Location = New System.Drawing.Point(473, 115)
        Me.Lab_FailBin.Name = "Lab_FailBin"
        Me.Lab_FailBin.Size = New System.Drawing.Size(42, 13)
        Me.Lab_FailBin.TabIndex = 41
        Me.Lab_FailBin.Text = "FailBin"
        '
        'Lab_Family
        '
        Me.Lab_Family.AutoSize = True
        Me.Lab_Family.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_Family.Location = New System.Drawing.Point(473, 85)
        Me.Lab_Family.Name = "Lab_Family"
        Me.Lab_Family.Size = New System.Drawing.Size(41, 13)
        Me.Lab_Family.TabIndex = 40
        Me.Lab_Family.Text = "Family"
        '
        'Lab_PartsID
        '
        Me.Lab_PartsID.AutoSize = True
        Me.Lab_PartsID.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_PartsID.Location = New System.Drawing.Point(474, 53)
        Me.Lab_PartsID.Name = "Lab_PartsID"
        Me.Lab_PartsID.Size = New System.Drawing.Size(44, 13)
        Me.Lab_PartsID.TabIndex = 39
        Me.Lab_PartsID.Text = "PartsID"
        '
        'Lab_FailItem
        '
        Me.Lab_FailItem.AutoSize = True
        Me.Lab_FailItem.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_FailItem.Location = New System.Drawing.Point(124, 145)
        Me.Lab_FailItem.Name = "Lab_FailItem"
        Me.Lab_FailItem.Size = New System.Drawing.Size(47, 13)
        Me.Lab_FailItem.TabIndex = 38
        Me.Lab_FailItem.Text = "FailItem"
        '
        'Lab_FailSite
        '
        Me.Lab_FailSite.AutoSize = True
        Me.Lab_FailSite.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_FailSite.Location = New System.Drawing.Point(124, 114)
        Me.Lab_FailSite.Name = "Lab_FailSite"
        Me.Lab_FailSite.Size = New System.Drawing.Size(43, 13)
        Me.Lab_FailSite.TabIndex = 37
        Me.Lab_FailSite.Text = "FailSite"
        '
        'Lab_TesterID
        '
        Me.Lab_TesterID.AutoSize = True
        Me.Lab_TesterID.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_TesterID.Location = New System.Drawing.Point(124, 85)
        Me.Lab_TesterID.Name = "Lab_TesterID"
        Me.Lab_TesterID.Size = New System.Drawing.Size(49, 13)
        Me.Lab_TesterID.TabIndex = 36
        Me.Lab_TesterID.Text = "TesterID"
        '
        'Lab_SendMan
        '
        Me.Lab_SendMan.AutoSize = True
        Me.Lab_SendMan.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Lab_SendMan.Location = New System.Drawing.Point(124, 53)
        Me.Lab_SendMan.Name = "Lab_SendMan"
        Me.Lab_SendMan.Size = New System.Drawing.Size(53, 13)
        Me.Lab_SendMan.TabIndex = 35
        Me.Lab_SendMan.Text = "SendMan"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.Location = New System.Drawing.Point(403, 113)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 15)
        Me.Label7.TabIndex = 34
        Me.Label7.Text = "Fail Bin:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(411, 83)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 15)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Family:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(399, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 15)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Parts_ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(45, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 15)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Fail Item:"
        '
        'Button2
        '
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.Location = New System.Drawing.Point(1145, 129)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(78, 39)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "修改"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(1061, 129)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(78, 39)
        Me.Button1.TabIndex = 29
        Me.Button1.Text = "查詢"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(49, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 15)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Fail Site:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(65, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 15)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Tester:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(37, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 15)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Send_Man:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DataGridView1)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(0, 213)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1416, 503)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(3, 18)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1410, 482)
        Me.DataGridView1.TabIndex = 0
        '
        'Revise
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1416, 716)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Revise"
        Me.Text = "Revise"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Lab_FailReason As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Lab_FailBin As System.Windows.Forms.Label
    Friend WithEvents Lab_Family As System.Windows.Forms.Label
    Friend WithEvents Lab_PartsID As System.Windows.Forms.Label
    Friend WithEvents Lab_FailItem As System.Windows.Forms.Label
    Friend WithEvents Lab_FailSite As System.Windows.Forms.Label
    Friend WithEvents Lab_TesterID As System.Windows.Forms.Label
    Friend WithEvents Lab_SendMan As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
