﻿Imports System.Data.OleDb

Public Class PMSControl
    '建立資料庫連接
    Private DBCon As New OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;" & _
                                         "Data Source=D:\PMS_Status.accdb;" & _
                                         "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True")

    ' PREPARE DB COMMAND
    Private DBCmd As OleDbCommand

    'DB DATA
    Public DBDA As OleDbDataAdapter
    Public DBDT As DataTable
    Public DBST As DataSet = New DataSet()

    'QUERY PARAMTERS
    Public Params As New List(Of OleDbParameter)

    'QUERY STSTISTICS

    Public RecordCount As Integer
    Public EXception As String

    Public Sub ExecQuery(ByVal Query As String)
        'RESET QUERY STATS
        RecordCount = 0
        EXception = ""

        Try
            'OPEN A CONNECTION
            DBCon.Open()

            'CRATE DB COMMAND
            DBCmd = New OleDbCommand(Query, DBCon)

            'LOAD PARAMS INTO DB COMMAND
            Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))

            'CLEAR PARAMS LIST
            Params.Clear()

            'EXECUTE COMMAND & FILL DATABLE
            DBDT = New DataTable
            DBDA = New OleDbDataAdapter(DBCmd)

            RecordCount = DBDA.Fill(DBDT)

        Catch ex As Exception
            EXception = ex.Message
        End Try

        'CLOSE DB CONNECTION
        If DBCon.State = ConnectionState.Open Then DBCon.Close()



    End Sub

    'INCLUDE QUERY & COMMAND PARAMETERS
    Public Sub AddParams(ByVal Name As String, ByVal Value As Object)

        Dim NewParam As New OleDbParameter(Name, Value)
        Params.Add(NewParam)


    End Sub

    Public Sub DBSTQuery(ByVal Query As String)
        'RESET QUERY STATS
        RecordCount = 0
        EXception = ""

        Try
            'OPEN A CONNECTION
            DBCon.Open()

            'CRATE DB COMMAND
            DBCmd = New OleDbCommand(Query, DBCon)

            'LOAD PARAMS INTO DB COMMAND
            Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))

            'CLEAR PARAMS LIST
            Params.Clear()

            'EXECUTE COMMAND & FILL DATABLE
            DBDT = New DataTable
            DBDA = New OleDbDataAdapter(DBCmd)
            RecordCount = DBDA.Fill(DBDT)


        Catch ex As Exception
            EXception = ex.Message
        End Try

        'CLOSE DB CONNECTION
        If DBCon.State = ConnectionState.Open Then DBCon.Close()



    End Sub


    Public Sub TEST(ByVal TB1 As String)
        'RESET QUERY STATS
        RecordCount = 0
        EXception = ""

        Try
            'OPEN A CONNECTION
            DBCon.Open()

            'CRATE DB COMMAND
            DBCmd = New OleDbCommand(TB1, DBCon)

            'LOAD PARAMS INTO DB COMMAND
            Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))

            'CLEAR PARAMS LIST
            Params.Clear()

            'EXECUTE COMMAND & FILL DATABLE
            DBDT = New DataTable
            DBDA = New OleDbDataAdapter(DBCmd)

            RecordCount = DBDA.Fill(DBDT)
            'DBST.Tables("a1").Columns.Remove(0)
            DBDA.Fill(DBST, "a1")



        Catch ex As Exception
            EXception = ex.Message
        End Try

        'CLOSE DB CONNECTION
        If DBCon.State = ConnectionState.Open Then DBCon.Close()
    End Sub

End Class
