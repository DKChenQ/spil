﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home_Screen
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home_Screen))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.AppionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReceiveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ComponentControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DutBoardDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditFailCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DutBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LBRemarkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.KPIKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DataEditEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AppionToolStripMenuItem, Me.ReceiveToolStripMenuItem, Me.ComponentControlToolStripMenuItem, Me.DutBoardDToolStripMenuItem, Me.LBRemarkToolStripMenuItem, Me.KPIKToolStripMenuItem, Me.DataEditEToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1384, 26)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AppionToolStripMenuItem
        '
        Me.AppionToolStripMenuItem.Name = "AppionToolStripMenuItem"
        Me.AppionToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.AppionToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.AppionToolStripMenuItem.Text = "建立維修單&(A)"
        '
        'ReceiveToolStripMenuItem
        '
        Me.ReceiveToolStripMenuItem.Name = "ReceiveToolStripMenuItem"
        Me.ReceiveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.ReceiveToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.ReceiveToolStripMenuItem.Text = "填寫維修單&(R)"
        '
        'ComponentControlToolStripMenuItem
        '
        Me.ComponentControlToolStripMenuItem.Name = "ComponentControlToolStripMenuItem"
        Me.ComponentControlToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.ComponentControlToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.ComponentControlToolStripMenuItem.Text = "Component control&(C)"
        '
        'DutBoardDToolStripMenuItem
        '
        Me.DutBoardDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditFailCodeToolStripMenuItem, Me.DutBoardToolStripMenuItem})
        Me.DutBoardDToolStripMenuItem.Name = "DutBoardDToolStripMenuItem"
        Me.DutBoardDToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DutBoardDToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.DutBoardDToolStripMenuItem.Text = "Dut Board(&D)"
        '
        'EditFailCodeToolStripMenuItem
        '
        Me.EditFailCodeToolStripMenuItem.Name = "EditFailCodeToolStripMenuItem"
        Me.EditFailCodeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.EditFailCodeToolStripMenuItem.Size = New System.Drawing.Size(233, 22)
        Me.EditFailCodeToolStripMenuItem.Text = "Edit Fail Code(&E)"
        '
        'DutBoardToolStripMenuItem
        '
        Me.DutBoardToolStripMenuItem.Name = "DutBoardToolStripMenuItem"
        Me.DutBoardToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.DutBoardToolStripMenuItem.Size = New System.Drawing.Size(233, 22)
        Me.DutBoardToolStripMenuItem.Text = "Dut Board(&B)"
        '
        'LBRemarkToolStripMenuItem
        '
        Me.LBRemarkToolStripMenuItem.Name = "LBRemarkToolStripMenuItem"
        Me.LBRemarkToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.LBRemarkToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.LBRemarkToolStripMenuItem.Text = "LB_Remark(&M)"
        '
        'KPIKToolStripMenuItem
        '
        Me.KPIKToolStripMenuItem.Name = "KPIKToolStripMenuItem"
        Me.KPIKToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.K), System.Windows.Forms.Keys)
        Me.KPIKToolStripMenuItem.Size = New System.Drawing.Size(58, 22)
        Me.KPIKToolStripMenuItem.Text = "KPI(&K)"
        '
        'DataEditEToolStripMenuItem
        '
        Me.DataEditEToolStripMenuItem.Name = "DataEditEToolStripMenuItem"
        Me.DataEditEToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.DataEditEToolStripMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.DataEditEToolStripMenuItem.Text = "Data_Edit(&E)"
        Me.DataEditEToolStripMenuItem.Visible = False
        '
        'Home_Screen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1384, 742)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Home_Screen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Home_Screen"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents AppionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReceiveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComponentControlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DutBoardDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditFailCodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DutBoardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LBRemarkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KPIKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataEditEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
