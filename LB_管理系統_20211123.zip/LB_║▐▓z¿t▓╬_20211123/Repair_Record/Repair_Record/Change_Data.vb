﻿Imports System.Data.OleDb

Public Class Change_Data

    Dim conn As OleDbConnection
    Dim Str As String

    Private Sub Change_Data_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

       
    End Sub

    Private Sub Change_Data_Load_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        HS_LoadBoard.DataGridView1.Enabled = True

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        conn = New OleDbConnection(H_Z_DBCon)

        If Trim(TextBox1.Text) = "" Or Trim(TextBox2.Text) = "" Or Trim(TextBox3.Text) = "" Or Trim(TextBox4.Text) = "" Then

            MessageBox.Show("欄位不得有空值")

        Else
            Dim cmd As OleDbCommand
            conn = New OleDbConnection(H_Z_DBCon)
            Str = " Update" & Fill_Data & "set Tester_ID = '" & TextBox1.Text & "', Fail_Site = '" & TextBox2.Text & "', Fail_Bin = '" & TextBox3.Text & "', Stage = '" & TextBox4.Text & "' where ID = " & RV_ID & "" '更新
            conn.Open()
            cmd = New OleDbCommand(Str, conn)
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()

            HS_LoadBoard.Lab_SendMan.Text = "" 'Send_Man:
            HS_LoadBoard.Lab_TesterID.Text = "" 'Tester:
            HS_LoadBoard.Lab_FailSite.Text = "" 'Fail Site:
            HS_LoadBoard.Lab_FailItem.Text = "" 'Fail Item:
            HS_LoadBoard.Lab_PartsID.Text = "" 'Parts_ID:
            HS_LoadBoard.Lab_Family.Text = "" 'Family:
            HS_LoadBoard.Lab_FailBin.Text = "" 'Fail Bin:
            HS_LoadBoard.Lab_FailReason.Text = ""
            HS_LoadBoard.Load_HW_Table_List()

            HS_LoadBoard.DataGridView1.Enabled = True
            Me.Close()

        End If




    End Sub
End Class