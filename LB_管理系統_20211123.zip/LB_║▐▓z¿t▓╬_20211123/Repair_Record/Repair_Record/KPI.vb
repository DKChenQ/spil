﻿Imports System.Data.OleDb
Imports System.Globalization
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.IO

Public Class KPI

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim ST, ET As String
        'Dim prompt As String = "請輸入起始日期: " & vbCrLf & vbCrLf & "EX: 2023/8/8"
        'Dim title As String = "日期"
        'Dim defaultResponse As String = "2023/8/8"
        'Dim sd As String = InputBox(prompt, title, defaultResponse)

        ST = Microsoft.VisualBasic.Format(DateTimePicker1.Value, "#yyyy/M/d 00:00:00#")
        ET = Microsoft.VisualBasic.Format(DateTimePicker2.Value, "#yyyy/M/d 23:59:59#")

        'ST = DateTimePicker1.Value.ToString("yyyy/MM/dd") & " 00:00:00"
        'ET = DateTimePicker2.Value.ToString("yyyy/MM/dd") & " 23:59:59"

        ' ST = Microsoft.VisualBasic.FormatDateTime(DateTimePicker1.Value, 2)
        ' ET = Microsoft.VisualBasic.FormatDateTime(DateTimePicker2.Value, 2)

        ' 如果使用者點擊取消，直接退出
        ' If sd = "" Then
        '     Exit Sub ' 提早結束當前方法
        ' End If

        ' 如果輸入為空白，提示錯誤
        'If sd.Trim() = "" Then
        '    MsgBox("請輸入有效的起始日期。", MsgBoxStyle.Exclamation)
        '    Exit Sub
        'End If

        Dim conn As New OleDbConnection(H_Z_DBCon)
        Dim table_name As String = "KPI"
        Dim date_time_column As String = "Cop_Date"
        Dim man_column As String = "Repair_Man"
        Dim status_item_column As String = "Now_Status"
        Dim Time_Total_column As String = "Time_Total"
        Dim QTY_column As String = "QTY"

        Dim sql_query As String = String.Format("SELECT {0}, {1}, {2}, {3}, {4} FROM {5} WHERE {0} BETWEEN {6} AND {7}", date_time_column, status_item_column, man_column, Time_Total_column, QTY_column, table_name, ST, ET)

        'Dim sql_query As String = String.Format("SELECT {1}, {2}, sum({3}) as ttotal , sum({4}) as Qtotal FROM {5} WHERE {0} BETWEEN {6} AND {7} GROUP BY {1},{2}", date_time_column, status_item_column, man_column, Time_Total_column, QTY_column, table_name, ST, ET)





        conn.Open()

        Dim cmd As New OleDbCommand(sql_query, conn)

        Dim results As OleDbDataReader = cmd.ExecuteReader()


        ' 建立 Excel Application 物件
        Dim excel As Excel.Application = New Excel.Application()

        excel.Visible = False

        ' 建立新的 Excel 工作簿
        Dim workbook As Excel.Workbook = excel.Workbooks.Add()


        ' 取得預設的工作表
        ' Dim excelWorksheet As Excel.Worksheet = workbook.Worksheets.Add(Before:=workbook.Worksheets(1))

        Dim excelWorksheet As Excel.Worksheet = excel.ActiveSheet
        excelWorksheet.Name = "List"


        ' 寫入欄位標題
        excelWorksheet.Cells(1, 1).Value = "維修日期"
        excelWorksheet.Cells(1, 2).Value = "維修人員"
        excelWorksheet.Cells(1, 3).Value = "維修狀態"
        excelWorksheet.Cells(1, 4).Value = "維修總時間"
        excelWorksheet.Cells(1, 5).Value = "維修件數"

        ' 取得資料並填入 Excel 工作表
        Dim row As Integer = 2
        While results.Read()
            excelWorksheet.Cells(row, 1).Value = results(date_time_column)
            excelWorksheet.Cells(row, 2).Value = results(man_column)
            excelWorksheet.Cells(row, 3).Value = results(status_item_column)
            excelWorksheet.Cells(row, 4).Value = results(Time_Total_column)
            excelWorksheet.Cells(row, 5).Value = results(QTY_column)
            row += 1
        End While

        results.Close()
        conn.Close()

        excelWorksheet.Columns.AutoFit()


        ' 設定 Excel 檔案的儲存路徑和檔名
        Dim FilePath As String = "d:\kpi_report_" & Format(Now(), "M-d HHmm") & "_" & ComboBox1.Text & ".xlsx"

        ' 儲存 Excel 檔案
        workbook.SaveAs(FilePath)

        ' 關閉並釋放資源
        workbook.Close(SaveChanges:=False)
        excel.Quit()
        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelWorksheet)
        System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook)
        System.Runtime.InteropServices.Marshal.ReleaseComObject(excel)

        ' 清除未關閉的 Excel 處理程序
        System.GC.Collect()

        MsgBox(FilePath)


    End Sub

    Private Sub KPI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ComboBox1.Items.Add("EL")
        ComboBox1.Items.Add("HS")
        ComboBox1.Items.Add("ZK")

        ComboBox1.SelectedIndex = 1
        H_Z_Menu = ComboBox1.Text

        'H_Z_Menu = Trim(UCase(InputBox("請輸入HS 或 ZK 或 EL:", "請輸入廠區:")))

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        ElseIf H_Z_Menu = "EL" Then
            H_Z_DBCon = EL_LB_Database
        ElseIf H_Z_Menu = "TEST" Then
            H_Z_DBCon = TEST_LB_Database
        End If

    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        H_Z_Menu = ComboBox1.Text

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        ElseIf H_Z_Menu = "EL" Then
            H_Z_DBCon = EL_LB_Database
        ElseIf H_Z_Menu = "TEST" Then
            H_Z_DBCon = TEST_LB_Database
        End If

    End Sub

End Class