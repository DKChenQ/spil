﻿' 載入設定檔
Imports System.Configuration
Imports System.IO.Ports
Imports System.Text
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Form2

    Private isConnected As Boolean = False
    Private Const Arduino_coed As String = "10"
    Private Const led_close As String = "21"
    Private result As Boolean = False
    Private builder As StringBuilder = New StringBuilder() ' 用於儲存接收的數據
    ' 在類別中添加新的 ResponseTimer
    Private WithEvents ResponseTimer As New Timer()

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        Timer1.Interval = 600000
        Timer1.Enabled = True

        UpdateDateTime()
        Label1.Text = "未連線"
        Button1.Text = "連線"
        RadioButton1.Text = "持續執行"
        RadioButton2.Text = "單次執行"
        Button2.Text = "測試"
        Label3.Text = "測試次數設定:"
        Label4.Text = "時間間隔設定:"
        Button3.Text = "清除"
        Button4.Text = "儲存"
        TextBox2.Multiline = True
        TextBox2.ScrollBars = ScrollBars.Vertical
        Label5.Text = ""

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        SerialPort1.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click 'port Conntect
        If isConnected Then
            Disconnect()
        Else
            If ComboBox1.SelectedItem IsNot Nothing Then
                Try
                    SerialPort1.PortName = ComboBox1.SelectedItem.ToString()
                    SerialPort1.BaudRate = 9600
                    SerialPort1.Parity = Parity.None
                    SerialPort1.DataBits = 8
                    SerialPort1.StopBits = StopBits.One
                    SerialPort1.Handshake = Handshake.None
                    SerialPort1.RtsEnable = True
                    SerialPort1.Open()
                    Connect()
                Catch ex As Exception
                    MsgBox(ComboBox1.SelectedItem.ToString() & " : 已與設備斷線，請確認!")
                End Try
            Else
                MsgBox("請選擇要連線的 COM Port！")
            End If
        End If

    End Sub

    Private Sub Connect()
        isConnected = True
        Label1.Text = "已連線到" & ComboBox1.SelectedItem.ToString()
        Label1.ForeColor = Color.FromArgb(110, 170, 45)
        Button1.Text = "斷線"
        ComboBox1.Enabled = False
    End Sub

    Private Sub Disconnect()
        isConnected = False
        Label1.Text = "已斷開連線"
        Label1.ForeColor = Color.FromArgb(255, 0, 0)
        Button1.Text = "連線"
        ComboBox1.Enabled = True
        If SerialPort1 IsNot Nothing Then
            If SerialPort1.IsOpen Then SerialPort1.Close()
            SerialPort1.Dispose()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click ' 測試

        Dim i As Integer
        Label5.Text = ""

        If Not SerialPort1.IsOpen Then
            MsgBox("已斷開連線！")
            Return
        End If

        If NumericUpDown1.Value = 0 Then


        Else

            ResponseTimer.Interval = 400 * NumericUpDown1.Value ' 1 秒，可以根據需要調整
            ResponseTimer.Enabled = False
            Dim test_items As Integer = NumericUpDown1.Value

            For i = 1 To test_items
                sendCommand(Arduino_coed)
                Application.DoEvents() ' 更新UI
            Next
            ResponseTimer.Start()
            sendCommand(led_close)
            TextBox2.Clear()


        End If
    End Sub
    Private Sub InvokeButton2Click() 'ARDUINO 實體按鈕 觸發
        If Me.InvokeRequired Then
            Me.Invoke(New MethodInvoker(AddressOf Button2.PerformClick))
        Else
            Button2.PerformClick()
        End If
    End Sub


    ' ResponseTimer 的 Tick 事件處理程序
    Private Sub ResponseTimer_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles ResponseTimer.Tick
        Result_pass() ' 在收到回應後執行 Result_pass
        ResponseTimer.Stop() ' 停止 Timer
    End Sub

    Private Sub UpdateDateTime()
        Dim now As DateTime = DateTime.Now
        Label2.Text = now.ToString("yyyy/MM/dd HH:mm:ss")
    End Sub

    Private WithEvents Timer1 As New Timer()

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        If SerialPort1.IsOpen Then
            Disconnect()
            MessageBox.Show("SerialPort已關閉")
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove
        Timer1.Stop()
        Timer1.Start()
    End Sub

    Private Sub sendCommand(ByVal command As String)
        SerialPort1.Write(command)
    End Sub

    Delegate Sub SetTextCallback(ByVal [text] As String)

    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        ' ReceivedText(SerialPort1.ReadExisting())

        Dim receivedData As String = SerialPort1.ReadExisting()

        If receivedData.Contains("BUTTON_PRESSED") Then
            InvokeButton2Click()
        End If

        ReceivedText(receivedData)

        ' Dim inData As String = SerialPort1.ReadExisting()
        '  ReceivedText(inData)

        ' MsgBox(inData.Count(Function(c) c = ","))

        ' 確認接收到的數據是否包含全部預期的項目
        ' If inData.Count(Function(c) c = ",") >= 4 * NumericUpDown1.Value Then
        '     Result_pass()
        ' End If

    End Sub

    Private Sub ReceivedText(ByVal [text] As String)

        ' If Me.TextBox2.InvokeRequired Then
        '     Dim x As New SetTextCallback(AddressOf ReceivedText)
        '    Me.Invoke(x, New Object() {(text)})
        ' Else
        '    Me.TextBox2.Text &= [text]
        ' End If

        If Me.TextBox2.InvokeRequired Then
            Dim x As New SetTextCallback(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.builder.Append([text])
            Me.TextBox2.Text = builder.ToString()
        End If

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Label5.Text = ""
        Me.builder.Length = 0
        TextBox2.Clear()
    End Sub

    Private Sub ComboBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ComboBox1.MouseClick
        Dim ports() As String = IO.Ports.SerialPort.GetPortNames()

        ComboBox1.Items.Clear()

        For Each port As String In ports
            ComboBox1.Items.Add(port)
        Next
    End Sub

    Private Sub Result_pass_1()
        Dim passCount As Integer = 0
        Dim expectedPassCount As Integer = 1 '4 * NumericUpDown1.Value
        Dim resultText As New StringBuilder()

        ' 拆分TextBox2中的文字，並計算"PASS"的數量
        Dim parts() As String = TextBox2.Text.Split(",")
        For Each part As String In parts
            If part.Trim().EndsWith("INVALID") Then
                passCount += 1
            End If
            resultText.AppendLine(part.Trim()) ' 將每個部分加到 resultText
        Next
        MsgBox(passCount)

        ' 將結果顯示在 Label5.Text
        Label5.Text = resultText.ToString()

        ' 檢查是否所有的測試都為"PASS"
        If passCount = expectedPassCount Then
            Label5.Text &= "FAIL"
            Label5.ForeColor = Color.FromArgb(255, 0, 0) ' 綠色
        Else
            Label5.Text &= "PASS"
            Label5.ForeColor = Color.FromArgb(110, 170, 45) '(255, 0, 0) ' 紅色
        End If

        ' 清空串口緩衝區
        ' ClearSerialBuffer()

    End Sub

    ' 測試結束後清空緩衝區
    Private Sub ClearSerialBuffer()
        If SerialPort1.IsOpen Then
            SerialPort1.DiscardInBuffer()
            SerialPort1.DiscardOutBuffer()
        End If
    End Sub

    Public Sub SaveToExcel()

        Dim xlApp As Excel.Application = New Excel.ApplicationClass

        If xlApp Is Nothing Then
            MessageBox.Show("Excel is not properly installed!")
            Return
        End If

        Try

            Dim workbook As Excel.Workbook = xlApp.Workbooks.Add
            Dim Worksheet As Excel.Worksheet = CType(workbook.Worksheets(1), Excel.Worksheet)

            Dim lines As String() = TextBox2.Text.Split(New String() {Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries)

            Worksheet.Cells(1, 1) = "通道"
            Worksheet.Cells(1, 2) = "測試值"
            Worksheet.Cells(1, 3) = "測試結果"

            For i As Integer = 0 To lines.Length - 1
                Dim parts As String() = lines(i).Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)
                For j As Integer = 0 To parts.Length - 1
                    Worksheet.Cells(i + 2, j + 1) = parts(j)
                Next
            Next

            Worksheet.Range("A1:C1").Interior.Color = RGB(0, 128, 0)
            Worksheet.Range("A1:C1").Font.Bold = True
            Worksheet.Range("A1:C1").Font.Color = RGB(255, 255, 255)
            
            Worksheet.Columns("A:C").HorizontalAlignment = -4108
            Worksheet.Columns("A:C").VerticalAlignment = -4108
            ' Worksheet.Range("A" & j & ":Y" & j).Borders.LineStyle = 1
            Worksheet.UsedRange.Borders.LineStyle = 1
            Worksheet.Columns.AutoFit()


            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 1

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                workbook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

            workbook.Close()

            releaseObject(Worksheet)
            releaseObject(workbook)
            releaseObject(xlApp)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

        End Try


    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        SaveToExcel()
    End Sub

    Private Sub Result_pass()

        Dim passCount As Integer = 0
        'Dim expectedPassCount As Integer = 1 ' 4 * NumericUpDown1.Value

        Dim content As String = TextBox2.Text
        Dim count As Integer = 0
        Dim index As Integer = content.IndexOf("INVALID")

        While index <> -1
            count += 1
            index = content.IndexOf("INVALID", index + 7) '4是"PASS"的長度
        End While

        '   MessageBox.Show("PASS 的數量為: " & count.ToString())

        ' 將結果顯示在 Label5.Text
        'Label5.Text = resultText.ToString()

        ' 檢查是否所有的測試都為"PASS"
        If count >= 1 Then
            Label5.Text &= "FAIL"
            Label5.ForeColor = Color.FromArgb(255, 0, 0) ' 綠色
        Else
            Label5.Text &= "PASS"
            Label5.ForeColor = Color.FromArgb(110, 170, 45) '(255, 0, 0) ' 紅色
        End If



    End Sub
   
   
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        Result_pass() '2023/11/2 測試

    End Sub
End Class
